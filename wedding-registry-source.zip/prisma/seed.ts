import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";

const prisma = new PrismaClient();
const BCRYPT_ROUNDS = 10;
const inviteCode = () => randomBytes(9).toString("base64url");

async function main() {
  // Idempotent: clear existing data in FK-safe order.
  await prisma.payment.deleteMany();
  await prisma.contribution.deleteMany();
  await prisma.item.deleteMany();
  await prisma.externalLink.deleteMany();
  await prisma.rsvp.deleteMany();
  await prisma.invite.deleteMany();
  await prisma.couple.deleteMany();

  // Couple (demo admin password: "password123").
  const couple = await prisma.couple.create({
    data: {
      partner1: "Alex",
      partner2: "Sam",
      weddingDate: new Date("2026-09-19"),
      theme: "sage",
      welcomeMessage:
        "We're so grateful you're here to celebrate with us — thank you for being part of our story.",
      mailingAddress: "Alex & Sam\n123 Maple Lane\nPortland, OR 97201",
      adminPasswordHash: await bcrypt.hash("password123", BCRYPT_ROUNDS),
      setupComplete: true,
    },
  });
  console.log('Demo admin password is "password123"');

  // Helper to create an item and return it.
  const createItem = (data: {
    name: string;
    description: string;
    priceCents: number;
    category?: string;
    allowPartial?: boolean;
    isCashGift?: boolean;
    fulfillment?: string;
    giftReceived?: boolean;
    closed?: boolean;
  }) => prisma.item.create({ data });

  // 1) Whole-item claim, couple wants it as a physical gift (not yet arrived).
  const mixer = await createItem({
    name: "Stand Mixer",
    category: "Kitchen",
    description: "A powerful stand mixer for all our baking adventures.",
    priceCents: 34999,
    fulfillment: "gift",
  });
  await prisma.contribution.create({
    data: {
      itemId: mixer.id,
      guestName: "Jordan",
      message: "So excited for you two!",
      amountCents: mixer.priceCents,
      guestContact: "jordan@example.com",
      thankYouSent: true,
      thankYouAt: new Date("2026-08-01"),
    },
  });

  // 2) Whole-item claim, converted to a cash pledge (with simulated Payment).
  const espresso = await createItem({
    name: "Espresso Machine",
    category: "Kitchen",
    description: "Café-quality espresso without leaving the house.",
    priceCents: 59900,
    fulfillment: "cash",
  });
  await prisma.contribution.create({
    data: {
      itemId: espresso.id,
      guestName: "Taylor",
      amountCents: espresso.priceCents,
    },
  });
  await prisma.payment.create({
    data: {
      itemId: espresso.id,
      amountCents: espresso.priceCents,
      status: "completed",
      provider: "simulated",
      providerRef: null,
    },
  });

  // 3) Whole-item claim, couple still undecided.
  const dutchOven = await createItem({
    name: "Cast Iron Dutch Oven",
    category: "Kitchen",
    description: "Perfect for slow braises, soups, and crusty bread.",
    priceCents: 12500,
  });
  await prisma.contribution.create({
    data: {
      itemId: dutchOven.id,
      guestName: "Casey",
      message: "Can't wait to celebrate!",
      amountCents: dutchOven.priceCents,
      needsAddress: true,
    },
  });

  // 4) Group gift, partially funded (in progress).
  const getaway = await createItem({
    name: "Weekend Getaway Fund",
    category: "Experiences",
    description: "Help send us off on a little post-wedding escape.",
    priceCents: 60000,
    allowPartial: true,
  });
  await prisma.contribution.createMany({
    data: [
      { itemId: getaway.id, guestName: "Priya", message: "Have a blast!", amountCents: 15000, guestContact: "priya@example.com" },
      { itemId: getaway.id, guestName: "Marco", amountCents: 10000 },
      { itemId: getaway.id, guestName: "Dana", message: "Cheers!", amountCents: 12000 },
    ],
  });

  // 5) Group gift, fully funded and converted to cash (with Payment).
  const dinnerware = await createItem({
    name: "Ceramic Dinnerware Set",
    category: "Kitchen",
    description: "Handsome, durable everyday plates and bowls.",
    priceCents: 15000,
    allowPartial: true,
    fulfillment: "cash",
  });
  await prisma.contribution.createMany({
    data: [
      { itemId: dinnerware.id, guestName: "Robin", amountCents: 7500 },
      { itemId: dinnerware.id, guestName: "Sasha", message: "To many dinners together!", amountCents: 7500 },
    ],
  });
  await prisma.payment.create({
    data: {
      itemId: dinnerware.id,
      amountCents: 15000,
      status: "completed",
      provider: "simulated",
      providerRef: null,
    },
  });

  // 6) Unclaimed item, still available.
  await createItem({
    name: "Egyptian Cotton Sheet Set",
    category: "Bedroom",
    description: "Soft, breathable sheets for lazy Sunday mornings.",
    priceCents: 18000,
  });

  // 7) First-class cash gift: open-ended, unrestricted, honest framing.
  const cashGift = await createItem({
    name: "Contribute to Our Adventures",
    category: "Experiences",
    description:
      "No fund, no fuss — an unrestricted cash gift we'll use however we like.",
    priceCents: 0, // open-ended, no goal
    allowPartial: true,
    isCashGift: true,
    fulfillment: "cash",
  });
  await prisma.contribution.createMany({
    data: [
      { itemId: cashGift.id, guestName: "Nadia", message: "Enjoy every minute!", amountCents: 5000 },
      { itemId: cashGift.id, guestName: "Owen", amountCents: 7500 },
    ],
  });
  await prisma.payment.create({
    data: {
      itemId: cashGift.id,
      amountCents: 12500,
      status: "completed",
      provider: "simulated",
      providerRef: null,
    },
  });

  // External registry links.
  await prisma.externalLink.createMany({
    data: [
      {
        label: "Our Amazon Registry",
        url: "https://www.amazon.com/wedding/registry",
        storeName: "Amazon",
        sortOrder: 0,
      },
      {
        label: "Crate & Barrel Registry",
        url: "https://www.crateandbarrel.com/gift-registry",
        storeName: "Crate & Barrel",
        sortOrder: 1,
      },
    ],
  });

  // Guest list (per-invite party-size limits).
  const raoInvite = await prisma.invite.create({
    data: { householdName: "The Rao Family", maxPartySize: 4, code: inviteCode() },
  });
  const marcoInvite = await prisma.invite.create({
    data: { householdName: "Marco + guest", maxPartySize: 2, code: inviteCode() },
  });
  await prisma.invite.create({
    data: { householdName: "Aunt Lucia", maxPartySize: 2, code: inviteCode() },
  });

  // RSVPs (some tied to an invitation).
  await prisma.rsvp.createMany({
    data: [
      { guestName: "Priya Rao", attending: true, partySize: 3, message: "Wouldn't miss it!", contact: "priya@example.com", inviteId: raoInvite.id },
      { guestName: "Marco Bianchi", attending: true, partySize: 1, inviteId: marcoInvite.id },
      { guestName: "Aunt Lucia", attending: false, message: "So sorry we can't make the trip — sending love!" },
    ],
  });

  console.log(`Created couple ${couple.partner1} & ${couple.partner2}`);
  console.log(
    "Created 7 items, 9 contributions, 3 payments, 2 external links, 3 invites, 3 RSVPs"
  );
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
