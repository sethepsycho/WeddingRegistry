# Wedding Registry - one-click launcher.
# Started by "Start Wedding Registry.bat". Sets everything up the first time,
# then just starts the app on every run.

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot   # scripts/ -> project root
Set-Location $root

function Write-Step($msg) { Write-Host ""; Write-Host ">> $msg" -ForegroundColor Cyan }
function Test-Port($port) {
  try {
    $c = New-Object System.Net.Sockets.TcpClient
    $c.Connect("127.0.0.1", $port); $c.Close(); return $true
  } catch { return $false }
}

Write-Host "======================================" -ForegroundColor Magenta
Write-Host "        Wedding Registry setup"          -ForegroundColor Magenta
Write-Host "======================================" -ForegroundColor Magenta

# 1) Node.js must be installed.
$hasNode = $false
try { node -v | Out-Null; $hasNode = $true } catch { $hasNode = $false }
if (-not $hasNode) {
  Write-Host ""
  Write-Host "Node.js is required and was not found on this computer." -ForegroundColor Yellow
  Write-Host "I'll open the download page. Install it (the big green button)," -ForegroundColor Yellow
  Write-Host "then run 'Start Wedding Registry' again." -ForegroundColor Yellow
  Start-Process "https://nodejs.org/en/download/prebuilt-installer"
  Read-Host "Press Enter to close"
  exit 1
}

# 2) Install app dependencies (first time only, or if incomplete).
if ((-not (Test-Path "node_modules")) -or (-not (Test-Path "node_modules/embedded-postgres"))) {
  Write-Step "Installing the app (first time only - this can take a few minutes)"
  & npm install
  if ($LASTEXITCODE -ne 0) { Read-Host "Install failed. Press Enter to close"; exit 1 }
}

# 3) Make sure the built-in database engine is ready (some npm setups skip the
#    automatic step, so we do it ourselves if the binary isn't there yet).
$pgBinary = "node_modules/@embedded-postgres/windows-x64/native/bin/postgres.exe"
$pgHydrate = "node_modules/@embedded-postgres/windows-x64/scripts/hydrate-symlinks.js"
if ((-not (Test-Path $pgBinary)) -and (Test-Path $pgHydrate)) {
  Write-Step "Preparing the built-in database engine"
  & node $pgHydrate
}

# 4) Create the configuration file (.env) if it doesn't exist yet.
if (-not (Test-Path ".env")) {
  Write-Step "Creating your configuration"
  $bytes = New-Object 'System.Byte[]' 32
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  $secret = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
  $envText =
    "DATABASE_URL=""postgresql://postgres:postgres@localhost:5433/wedding""`r`n" +
    "SESSION_SECRET=""$secret""`r`n" +
    "PAYMENT_PROVIDER=""simulated""`r`n" +
    "EMAIL_PROVIDER=""none""`r`n" +
    "STORAGE_PROVIDER=""none""`r`n"
  [System.IO.File]::WriteAllText((Join-Path $root ".env"), $envText)
}

# 5) Start the local database (unless it's already running).
$startedDb = $false
if (-not (Test-Port 5433)) {
  Write-Step "Starting the database"
  $db = Start-Process node -ArgumentList "scripts/local-db.mjs" -PassThru -WindowStyle Hidden
  $startedDb = $true
  $waited = 0
  while (-not (Test-Port 5433) -and $waited -lt 60) { Start-Sleep -Seconds 1; $waited++ }
  if (-not (Test-Port 5433)) { Read-Host "The database did not start. Press Enter to close"; exit 1 }
}

# 6) Create/update the database tables.
Write-Step "Preparing the database"
& npx prisma db push --skip-generate
if ($LASTEXITCODE -ne 0) { Read-Host "Database preparation failed. Press Enter to close"; exit 1 }

# 7) Load friendly demo content the very first time only.
if (-not (Test-Path ".localdb/seeded")) {
  Write-Step "Adding a few example gifts to get you started"
  & npm run db:seed
  New-Item -ItemType Directory -Force -Path ".localdb" | Out-Null
  New-Item -ItemType File -Force -Path ".localdb/seeded" | Out-Null
}

# 8) Start the website (unless it's already running) and open the browser.
$startedApp = $false
if (-not (Test-Port 3000)) {
  Write-Step "Starting your registry website"
  $app = Start-Process npm -ArgumentList "run","dev" -PassThru -WindowStyle Hidden
  $startedApp = $true
  $waited = 0
  while (-not (Test-Port 3000) -and $waited -lt 90) { Start-Sleep -Seconds 1; $waited++ }
}

Start-Process "http://localhost:3000"

Write-Host ""
Write-Host "======================================" -ForegroundColor Green
Write-Host "  Your registry is running!"            -ForegroundColor Green
Write-Host "  It just opened in your web browser."   -ForegroundColor Green
Write-Host "  Address: http://localhost:3000"        -ForegroundColor Green
Write-Host ""
Write-Host "  KEEP THIS WINDOW OPEN while you use it." -ForegroundColor Yellow
Write-Host "  Close this window to stop the registry." -ForegroundColor Yellow
Write-Host "======================================" -ForegroundColor Green

# 9) Wait here until the user closes the window; then tidy up what we started.
try {
  if ($startedApp) { Wait-Process -Id $app.Id }
  else { Read-Host "Press Enter to stop the registry" }
} finally {
  if ($startedApp -and $app -and -not $app.HasExited) { try { Stop-Process -Id $app.Id -Force } catch {} }
  if ($startedDb  -and $db  -and -not $db.HasExited)  { try { Stop-Process -Id $db.Id  -Force } catch {} }
}
