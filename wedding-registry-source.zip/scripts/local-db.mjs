// Runs a self-contained local PostgreSQL for people who don't want to install a
// database. Uses `embedded-postgres` (a real Postgres binary, no admin rights),
// stores data under `.localdb/` in the project, and stays running until stopped.
//
// The launcher starts this in the background. You normally never run it directly.
import EmbeddedPostgres from "embedded-postgres";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.join(__dirname, "..");

const port = Number(process.env.LOCAL_DB_PORT || 5433);
const dataDir =
  process.env.LOCAL_DB_DIR || path.join(projectRoot, ".localdb", "pgdata");

const pg = new EmbeddedPostgres({
  databaseDir: dataDir,
  user: "postgres",
  password: "postgres",
  port,
  persistent: true,
});

async function main() {
  const alreadyInitialized = existsSync(path.join(dataDir, "PG_VERSION"));
  if (!alreadyInitialized) {
    console.log("Setting up the database for the first time...");
    await pg.initialise();
  }

  try {
    await pg.start();
  } catch (err) {
    // Most likely the port is already in use because the database is already
    // running from a previous launch. That's fine — just reuse it.
    console.log(
      `Database already running on port ${port} (or failed to start): ${
        err instanceof Error ? err.message : err
      }`
    );
    console.log(`READY: postgresql://postgres:postgres@localhost:${port}/wedding`);
    keepAlive();
    return;
  }

  try {
    await pg.createDatabase("wedding");
  } catch {
    // Database already exists — expected on every run after the first.
  }

  console.log(`READY: postgresql://postgres:postgres@localhost:${port}/wedding`);
  keepAlive();
}

function keepAlive() {
  // Keep the process (and the Postgres child) alive until the launcher stops it.
  setInterval(() => {}, 1 << 30);
}

async function shutdown() {
  try {
    await pg.stop();
  } catch {
    // ignore
  }
  process.exit(0);
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

main().catch((err) => {
  console.error("Could not start the local database:", err);
  process.exit(1);
});
