// Empties the database so you can preview the brand-new "first run" setup
// screen (names / date / theme / admin password).
//
//   npm run db:blank    <- clears everything
//   npm run db:seed     <- puts the example demo content back
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  await prisma.payment.deleteMany();
  await prisma.contribution.deleteMany();
  await prisma.item.deleteMany();
  await prisma.externalLink.deleteMany();
  await prisma.rsvp.deleteMany();
  await prisma.invite.deleteMany();
  await prisma.couple.deleteMany();
  console.log(
    "Database cleared. Open http://localhost:3000 to see the first-run setup screen."
  );
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
