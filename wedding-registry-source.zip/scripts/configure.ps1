# Wedding Registry - friendly setup wizard for the optional extras
# (card payments, email notifications, photo uploads). Run it any time.

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$envPath = Join-Path $root ".env"

function Set-EnvVar($key, $value) {
  $lines = @()
  if (Test-Path $envPath) { $lines = @([System.IO.File]::ReadAllLines($envPath)) }
  $newLine = "$key=""$value"""
  $found = $false
  for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match ("^\s*" + [regex]::Escape($key) + "\s*=")) {
      $lines[$i] = $newLine; $found = $true
    }
  }
  if (-not $found) { $lines += $newLine }
  [System.IO.File]::WriteAllLines($envPath, $lines)
}

if (-not (Test-Path $envPath)) {
  # Minimal config so the wizard can run before the first launch.
  Set-EnvVar "PAYMENT_PROVIDER" "simulated"
  Set-EnvVar "EMAIL_PROVIDER"   "none"
  Set-EnvVar "STORAGE_PROVIDER" "none"
}

Write-Host "======================================" -ForegroundColor Magenta
Write-Host "     Optional extras setup wizard"      -ForegroundColor Magenta
Write-Host "======================================" -ForegroundColor Magenta
Write-Host ""
Write-Host "Answer y (yes) or n (no) for each. You can leave anything for later,"
Write-Host "and run this again whenever you want."
Write-Host ""

# --- Card payments (Stripe) ---
Write-Host "----- Card payments (Stripe) - ADVANCED / developer feature -----" -ForegroundColor Cyan
Write-Host "This connects Stripe, but it does NOT charge guests' cards on its own -"
Write-Host "collecting a card needs an extra step a developer has to add (see README)."
Write-Host "Most couples skip this: guests pay you directly and you track it in the app."
$ans = Read-Host "Set up Stripe anyway? (y/n)"
if ($ans -eq "y") {
  $sk = Read-Host "Paste your Stripe SECRET key (starts with sk_)"
  $wh = Read-Host "Paste your Stripe WEBHOOK secret (starts with whsec_) or press Enter to skip"
  if ($sk) {
    Set-EnvVar "PAYMENT_PROVIDER"      "stripe"
    Set-EnvVar "STRIPE_SECRET_KEY"     $sk
    if ($wh) { Set-EnvVar "STRIPE_WEBHOOK_SECRET" $wh }
    Write-Host "Installing Stripe support..." -ForegroundColor Green
    & npm install stripe | Out-Null
    Write-Host "Card payments enabled." -ForegroundColor Green
  } else {
    Write-Host "No key entered - skipping." -ForegroundColor Yellow
  }
}
Write-Host ""

# --- Email notifications (Resend) ---
Write-Host "----- Email notifications (Resend) -----" -ForegroundColor Cyan
Write-Host "Emails you when a gift is claimed or an RSVP arrives. You'll need a free"
Write-Host "Resend account at https://resend.com  ->  API Keys."
$ans = Read-Host "Set up email notifications now? (y/n)"
if ($ans -eq "y") {
  $key  = Read-Host "Paste your Resend API key (starts with re_)"
  $from = Read-Host "The 'from' address to send from (e.g. hello@yourdomain.com)"
  if ($key) {
    Set-EnvVar "EMAIL_PROVIDER" "resend"
    Set-EnvVar "RESEND_API_KEY" $key
    if ($from) { Set-EnvVar "EMAIL_FROM" $from }
    Write-Host "Installing email support..." -ForegroundColor Green
    & npm install resend | Out-Null
    Write-Host "Email notifications enabled." -ForegroundColor Green
    Write-Host "Remember to set the notification address in the admin (Couple & event)." -ForegroundColor Yellow
  } else {
    Write-Host "No key entered - skipping." -ForegroundColor Yellow
  }
}
Write-Host ""

# --- Photo uploads (Vercel Blob) ---
Write-Host "----- Photo uploads (Vercel Blob) -----" -ForegroundColor Cyan
Write-Host "Lets you upload gift photos instead of pasting image links. You'll need a"
Write-Host "free Vercel account, a Blob store, and its read-write token."
$ans = Read-Host "Set up photo uploads now? (y/n)"
if ($ans -eq "y") {
  $token = Read-Host "Paste your Vercel Blob read-write token (starts with vercel_blob_rw_)"
  if ($token) {
    Set-EnvVar "STORAGE_PROVIDER"       "vercel-blob"
    Set-EnvVar "BLOB_READ_WRITE_TOKEN"  $token
    Write-Host "Installing photo upload support..." -ForegroundColor Green
    & npm install "@vercel/blob" | Out-Null
    Write-Host "Photo uploads enabled." -ForegroundColor Green
  } else {
    Write-Host "No token entered - skipping." -ForegroundColor Yellow
  }
}

Write-Host ""
Write-Host "======================================" -ForegroundColor Green
Write-Host "  All set!"                              -ForegroundColor Green
Write-Host "  Close 'Start Wedding Registry' and open it again"  -ForegroundColor Green
Write-Host "  for your changes to take effect."      -ForegroundColor Green
Write-Host "======================================" -ForegroundColor Green
Read-Host "Press Enter to close"
