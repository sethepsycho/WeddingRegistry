import bcrypt from "bcryptjs";
import { createHmac, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

const COOKIE_NAME = "wr_admin_session";
const MAX_AGE_SECONDS = 60 * 60 * 24 * 7; // 7 days
export const BCRYPT_ROUNDS = 10;
// A reveal token (for the address-reveal flow) is short-lived: a guest reveals
// the address right after claiming, not indefinitely.
const REVEAL_MAX_AGE_SECONDS = 60 * 30; // 30 minutes

// --- base64url helpers -----------------------------------------------------
function base64UrlEncode(buffer: Buffer): string {
  return buffer
    .toString("base64")
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}

function base64UrlDecode(str: string): Buffer {
  const normalized = str.replace(/-/g, "+").replace(/_/g, "/");
  const padding = (4 - (normalized.length % 4)) % 4;
  return Buffer.from(normalized + "=".repeat(padding), "base64");
}

// --- password hashing ------------------------------------------------------
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, BCRYPT_ROUNDS);
}

export async function verifyPassword(
  plain: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// --- session token ---------------------------------------------------------
function sign(body: string, secret: string): string {
  return base64UrlEncode(createHmac("sha256", secret).update(body).digest());
}

export async function setAdminSession(): Promise<void> {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    // Fail closed: never issue a session we cannot later verify.
    throw new Error("SESSION_SECRET is not set");
  }

  const payload = { v: 1, iat: Math.floor(Date.now() / 1000) };
  const body = base64UrlEncode(Buffer.from(JSON.stringify(payload), "utf-8"));
  const token = `${body}.${sign(body, secret)}`;

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  });
}

export async function clearAdminSession(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

// Reads and validates the session cookie. Must never throw.
export async function isAdminAuthenticated(): Promise<boolean> {
  const secret = process.env.SESSION_SECRET;
  if (!secret) return false;

  try {
    const cookieStore = await cookies();
    const raw = cookieStore.get(COOKIE_NAME)?.value;
    if (!raw) return false;

    const parts = raw.split(".");
    if (parts.length !== 2) return false;
    const [body, signature] = parts;

    const expected = sign(body, secret);
    const sigBuf = Buffer.from(signature);
    const expBuf = Buffer.from(expected);
    // timingSafeEqual throws on length mismatch, so guard first.
    if (sigBuf.length !== expBuf.length) return false;
    if (!timingSafeEqual(sigBuf, expBuf)) return false;

    const payload = JSON.parse(base64UrlDecode(body).toString("utf-8"));
    if (payload.v !== 1 || typeof payload.iat !== "number") return false;

    const ageSeconds = Math.floor(Date.now() / 1000) - payload.iat;
    return ageSeconds >= 0 && ageSeconds <= MAX_AGE_SECONDS;
  } catch {
    return false;
  }
}

// --- address-reveal token --------------------------------------------------
// Issued to a guest who just claimed a physical gift and opted to need the
// couple's mailing address. Proves that opt-in so the address endpoint isn't
// world-readable. Signed like the session token but carries the contribution id.
export function createRevealToken(contributionId: string): string | null {
  const secret = process.env.SESSION_SECRET;
  if (!secret) return null;
  const payload = { cid: contributionId, iat: Math.floor(Date.now() / 1000) };
  const body = base64UrlEncode(Buffer.from(JSON.stringify(payload), "utf-8"));
  return `${body}.${sign(body, secret)}`;
}

// Returns the contribution id the token was issued for, or null if invalid/expired.
export function verifyRevealToken(token: string): string | null {
  const secret = process.env.SESSION_SECRET;
  if (!secret) return null;
  try {
    const parts = token.split(".");
    if (parts.length !== 2) return null;
    const [body, signature] = parts;

    const expected = sign(body, secret);
    const sigBuf = Buffer.from(signature);
    const expBuf = Buffer.from(expected);
    if (sigBuf.length !== expBuf.length) return null;
    if (!timingSafeEqual(sigBuf, expBuf)) return null;

    const payload = JSON.parse(base64UrlDecode(body).toString("utf-8"));
    if (typeof payload.cid !== "string" || typeof payload.iat !== "number") {
      return null;
    }
    const ageSeconds = Math.floor(Date.now() / 1000) - payload.iat;
    if (ageSeconds < 0 || ageSeconds > REVEAL_MAX_AGE_SECONDS) return null;
    return payload.cid;
  } catch {
    return null;
  }
}
