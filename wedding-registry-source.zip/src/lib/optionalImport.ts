// Import an OPTIONAL peer dependency at runtime.
//
// The module specifier is passed through a Function-constructed dynamic import
// so the bundler (webpack/Next) cannot statically analyze it and therefore does
// NOT try to resolve the package at build time. This lets integration SDKs
// (stripe, resend, @vercel/blob) stay optional: they only need to be installed
// if the corresponding provider is actually enabled. If a provider is selected
// but its package isn't installed, this throws a clear, actionable error.
const dynamicImport = new Function("m", "return import(m)") as (
  m: string
) => Promise<any>;

export async function optionalImport(moduleName: string): Promise<any> {
  try {
    return await dynamicImport(moduleName);
  } catch {
    throw new Error(
      `Optional package "${moduleName}" is not installed. ` +
        `Run: npm install ${moduleName}`
    );
  }
}
