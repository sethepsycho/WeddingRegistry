import { prisma } from "@/lib/prisma";

// The app is single-tenant: there is at most one Couple row, created during
// first-run setup. These helpers centralize reading it.

// Full couple row — use only in admin/auth/address contexts. Includes
// adminPasswordHash and mailingAddress, so NEVER pass this to a public page.
export async function getCouple() {
  return prisma.couple.findFirst();
}

// Safe projection for guest-facing pages. Excludes adminPasswordHash and
// mailingAddress so those can never end up in a public page's serialized data.
export async function getPublicCouple() {
  return prisma.couple.findFirst({
    select: {
      partner1: true,
      partner2: true,
      weddingDate: true,
      theme: true,
      welcomeMessage: true,
      setupComplete: true,
      rsvpEnabled: true,
      rsvpDefaultMaxParty: true,
    },
  });
}

export async function isSetupComplete(): Promise<boolean> {
  const couple = await getCouple();
  return Boolean(couple?.setupComplete);
}
