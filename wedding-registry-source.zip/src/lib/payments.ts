import { prisma } from "@/lib/prisma";

export interface CreatePaymentInput {
  itemId: string;
  amountCents: number;
}

export interface PaymentResult {
  provider: string;
  providerRef: string | null;
  status: "pending" | "completed" | "failed";
}

// A payment provider knows how to record a cash pledge. Implementations must be
// swappable behind getPaymentProvider() with no other code changes.
export interface PaymentProvider {
  readonly name: string;
  createPayment(input: CreatePaymentInput): Promise<PaymentResult>;
}

// The default provider — records a pledge in the DB without moving real money.
class SimulatedPaymentProvider implements PaymentProvider {
  readonly name = "simulated";
  async createPayment(_input: CreatePaymentInput): Promise<PaymentResult> {
    return { provider: "simulated", providerRef: null, status: "completed" };
  }
}

// With Stripe, real card collection happens in /api/checkout (Stripe Checkout).
// So this only records a PLEDGE (a promise) — e.g. when the couple manually
// marks a claimed item as cash. It never charges a card here.
class StripePaymentProvider implements PaymentProvider {
  readonly name = "stripe";
  async createPayment(_input: CreatePaymentInput): Promise<PaymentResult> {
    return { provider: "stripe", providerRef: null, status: "pending" };
  }
}

// The single point where the active provider is selected. Defaults to simulated.
export function getPaymentProvider(): PaymentProvider {
  const providerName = process.env.PAYMENT_PROVIDER || "simulated";
  switch (providerName) {
    case "simulated":
      return new SimulatedPaymentProvider();
    case "stripe":
      return new StripePaymentProvider();
    default:
      throw new Error(
        `Payment provider "${providerName}" is not implemented. ` +
          `See the README "Extending this template" section for how to add one.`
      );
  }
}

// True when real card payments (Stripe Checkout) are configured and available.
export function isCardPaymentEnabled(): boolean {
  return (
    process.env.PAYMENT_PROVIDER === "stripe" &&
    Boolean(process.env.STRIPE_SECRET_KEY)
  );
}

// Records/updates the pledge for an item (bookkeeping only — no charge). The
// pledged amount is the total actually contributed toward the item.
export async function recordCashPledge(itemId: string): Promise<void> {
  const item = await prisma.item.findUnique({
    where: { id: itemId },
    include: { contributions: true },
  });
  if (!item) {
    throw new Error(`Item ${itemId} not found.`);
  }

  const amountCents = item.contributions.reduce(
    (sum, c) => sum + c.amountCents,
    0
  );

  const result = await getPaymentProvider().createPayment({
    itemId,
    amountCents,
  });

  await prisma.payment.upsert({
    where: { itemId },
    create: {
      itemId,
      amountCents,
      status: result.status,
      provider: result.provider,
      providerRef: result.providerRef,
    },
    update: {
      amountCents,
      status: result.status,
      provider: result.provider,
      providerRef: result.providerRef,
    },
  });
}

// Removes the pledge when an item is switched back to a physical gift.
export async function removeCashPledge(itemId: string): Promise<void> {
  await prisma.payment.deleteMany({ where: { itemId } });
}

// Called by the Stripe webhook AFTER a guest actually pays via Checkout. Records
// the paid contribution and marks the item's Payment as collected.
export async function recordPaidContribution(input: {
  itemId: string;
  guestName: string;
  message: string | null;
  contact: string | null;
  amountCents: number;
  providerRef: string | null;
}): Promise<void> {
  await prisma.contribution.create({
    data: {
      itemId: input.itemId,
      guestName: input.guestName,
      message: input.message,
      guestContact: input.contact,
      amountCents: input.amountCents,
      needsAddress: false,
    },
  });

  const item = await prisma.item.findUnique({
    where: { id: input.itemId },
    include: { contributions: true },
  });
  const funded = item
    ? item.contributions.reduce((sum, c) => sum + c.amountCents, 0)
    : input.amountCents;

  await prisma.payment.upsert({
    where: { itemId: input.itemId },
    create: {
      itemId: input.itemId,
      amountCents: funded,
      provider: "stripe",
      status: "completed",
      providerRef: input.providerRef,
    },
    update: {
      amountCents: funded,
      provider: "stripe",
      status: "completed",
      providerRef: input.providerRef,
    },
  });
}
