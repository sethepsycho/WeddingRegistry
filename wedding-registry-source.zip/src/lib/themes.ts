// Theme registry. Each key maps to a CSS variable block defined in
// src/app/globals.css as `[data-theme="<key>"] { ... }`. The couple picks
// one during setup / in the admin; the root layout applies it via
// `<html data-theme={theme}>`.

export type ThemeKey = "classic" | "rose" | "sage" | "midnight";

export interface ThemeOption {
  key: ThemeKey;
  label: string;
  /** A representative accent color, used to render swatches in the UI. */
  swatch: string;
}

export const THEMES: ThemeOption[] = [
  { key: "classic", label: "Classic", swatch: "#b08968" },
  { key: "rose", label: "Rose", swatch: "#c76a7a" },
  { key: "sage", label: "Sage", swatch: "#6f8f6a" },
  { key: "midnight", label: "Midnight", swatch: "#5b6bb0" },
];

export const DEFAULT_THEME: ThemeKey = "classic";

export function isValidTheme(value: string): value is ThemeKey {
  return THEMES.some((t) => t.key === value);
}

export function normalizeTheme(value: string | null | undefined): ThemeKey {
  return value && isValidTheme(value) ? value : DEFAULT_THEME;
}
