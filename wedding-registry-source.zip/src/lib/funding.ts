// Pure helpers for an item's group-funding state. Safe to import from both
// server components and client components (no Prisma / no side effects).

export interface FundableItem {
  priceCents: number;
  allowPartial: boolean;
  closed: boolean;
  contributions: { amountCents: number }[];
}

export function fundedCents(item: FundableItem): number {
  return item.contributions.reduce((sum, c) => sum + c.amountCents, 0);
}

export function remainingCents(item: FundableItem): number {
  return Math.max(0, item.priceCents - fundedCents(item));
}

// A priced item is fully funded once contributions meet its price.
export function isFullyFunded(item: FundableItem): boolean {
  return item.priceCents > 0 && fundedCents(item) >= item.priceCents;
}

// Can a guest still contribute?
// - group-funding items: until fully funded or closed
// - whole-item ("claim") items: only while unclaimed (no contribution) and open
export function canContribute(item: FundableItem): boolean {
  if (item.closed) return false;
  if (item.allowPartial) return !isFullyFunded(item);
  return item.contributions.length === 0;
}

// Funding is settled (couple's fulfillment decision becomes meaningful) once the
// item is fully funded or the couple has closed it early.
export function isSettled(item: FundableItem): boolean {
  return item.closed || isFullyFunded(item);
}

// Progress toward the goal, 0..100 (0 when there is no price goal).
export function fundedPercent(item: FundableItem): number {
  if (item.priceCents <= 0) return 0;
  return Math.min(100, Math.round((fundedCents(item) / item.priceCents) * 100));
}
