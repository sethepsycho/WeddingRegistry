import { prisma } from "@/lib/prisma";
import { optionalImport } from "@/lib/optionalImport";

// Plug-and-play email abstraction. Default is a no-op (logs only) so the app
// works with zero configuration; set EMAIL_PROVIDER=resend (+ RESEND_API_KEY)
// to actually send. See README "Extending this template".

export interface EmailMessage {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

export interface EmailProvider {
  readonly name: string;
  send(message: EmailMessage): Promise<void>;
}

// Default provider — sends nothing, just logs. Keeps the app config-free.
class NoopEmailProvider implements EmailProvider {
  readonly name = "none";

  async send(message: EmailMessage): Promise<void> {
    console.log("[email:noop] would send:", message.to, message.subject);
  }
}

// Optional Resend adapter. The SDK is loaded lazily (and the specifier is cast
// to string) so `resend` is only required when this provider is selected.
class ResendEmailProvider implements EmailProvider {
  readonly name = "resend";

  async send(message: EmailMessage): Promise<void> {
    if (!process.env.RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY is not set");
    }

    const mod = await optionalImport("resend");
    const Resend = mod.Resend;
    const resend = new Resend(process.env.RESEND_API_KEY);

    await resend.emails.send({
      from: process.env.EMAIL_FROM || "Wedding Registry <onboarding@resend.dev>",
      to: message.to,
      subject: message.subject,
      text: message.text,
      html: message.html,
    });
  }
}

// The single place a provider is selected.
export function getEmailProvider(): EmailProvider {
  const provider = process.env.EMAIL_PROVIDER || "none";
  switch (provider) {
    case "none":
      return new NoopEmailProvider();
    case "resend":
      return new ResendEmailProvider();
    default:
      throw new Error(
        `Unknown email provider "${provider}". See the README ` +
          `"Extending this template" section.`
      );
  }
}

// Fire-and-forget: never throws, so a failed notification can't break the
// request that triggered it.
export async function sendEmailSafe(message: EmailMessage): Promise<void> {
  try {
    await getEmailProvider().send(message);
  } catch (err) {
    console.error("[email] send failed:", err);
  }
}

// Notify the couple at their configured address, if any.
export async function notifyCouple(input: {
  subject: string;
  text: string;
  html?: string;
}): Promise<void> {
  try {
    const couple = await prisma.couple.findFirst({
      select: { notifyEmail: true },
    });
    if (couple?.notifyEmail) {
      await sendEmailSafe({
        to: couple.notifyEmail,
        subject: input.subject,
        text: input.text,
        html: input.html,
      });
    }
  } catch (err) {
    console.error("[email] notifyCouple failed:", err);
  }
}
