// Plug-and-play image storage abstraction. Disabled by default (the app uses
// photo URLs), with an optional Vercel Blob adapter selected via STORAGE_PROVIDER.
// See README "Extending this template".

import { optionalImport } from "@/lib/optionalImport";

export interface StorageProvider {
  readonly name: string;
  readonly enabled: boolean;
  upload(file: File): Promise<{ url: string }>;
}

// Default: uploads off. The admin form falls back to a photo URL field.
class DisabledStorageProvider implements StorageProvider {
  readonly name = "none";
  readonly enabled = false;

  async upload(_file: File): Promise<{ url: string }> {
    throw new Error("Image uploads are not configured (set STORAGE_PROVIDER).");
  }
}

// Optional Vercel Blob adapter. SDK is lazy-loaded (specifier cast to string)
// so `@vercel/blob` is only required when this provider is selected.
class VercelBlobStorageProvider implements StorageProvider {
  readonly name = "vercel-blob";
  readonly enabled = Boolean(process.env.BLOB_READ_WRITE_TOKEN);

  async upload(file: File): Promise<{ url: string }> {
    const mod = await optionalImport("@vercel/blob");
    const put = mod.put;
    const pathname = `items/${Date.now()}-${file.name}`;
    const blob = await put(pathname, file, {
      access: "public",
      token: process.env.BLOB_READ_WRITE_TOKEN,
    });
    return { url: blob.url };
  }
}

export function getStorageProvider(): StorageProvider {
  const providerName = process.env.STORAGE_PROVIDER || "none";
  switch (providerName) {
    case "none":
      return new DisabledStorageProvider();
    case "vercel-blob":
      return new VercelBlobStorageProvider();
    default:
      throw new Error(
        `Unknown storage provider "${providerName}". See the README ` +
          `"Extending this template" section.`
      );
  }
}

export function isUploadsEnabled(): boolean {
  try {
    return getStorageProvider().enabled;
  } catch {
    return false;
  }
}
