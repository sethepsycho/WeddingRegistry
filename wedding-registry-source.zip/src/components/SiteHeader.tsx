import Link from "next/link";

// Shared server component used on the guest-facing pages.
export default function SiteHeader({
  coupleName,
  showRegistryLink = true,
  showRsvpLink = false,
}: {
  coupleName: string;
  showRegistryLink?: boolean;
  showRsvpLink?: boolean;
}) {
  return (
    <header className="site-header">
      <div className="container site-header-inner">
        <Link href="/" className="brand">
          {coupleName}
        </Link>
        {(showRegistryLink || showRsvpLink) && (
          <nav style={{ display: "flex", gap: "0.5rem" }}>
            {showRegistryLink && (
              <Link href="/registry" className="btn btn-secondary">
                Registry
              </Link>
            )}
            {showRsvpLink && (
              <Link href="/rsvp" className="btn btn-secondary">
                RSVP
              </Link>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
