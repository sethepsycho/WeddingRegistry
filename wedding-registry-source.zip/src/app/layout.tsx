import "./globals.css";
import { getPublicCouple } from "@/lib/config";
import { normalizeTheme } from "@/lib/themes";

export const metadata = {
  title: "Wedding Registry",
  description: "Celebrate with us",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Resilient to an unreachable/unmigrated DB (e.g. during build or first boot):
  // fall back to the default theme rather than crashing the whole app.
  let theme = normalizeTheme(undefined);
  try {
    const couple = await getPublicCouple();
    theme = normalizeTheme(couple?.theme);
  } catch {
    // keep default theme
  }

  return (
    <html lang="en" data-theme={theme}>
      <body>{children}</body>
    </html>
  );
}
