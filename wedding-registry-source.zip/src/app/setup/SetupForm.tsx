"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { THEMES } from "@/lib/themes";

export default function SetupForm() {
  const [partner1, setPartner1] = useState("");
  const [partner2, setPartner2] = useState("");
  const [weddingDate, setWeddingDate] = useState("");
  const [theme, setTheme] = useState("classic");
  const [welcomeMessage, setWelcomeMessage] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const res = await fetch("/api/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          partner1,
          partner2,
          weddingDate,
          theme,
          welcomeMessage,
          adminPassword: password,
        }),
      });

      if (res.ok) {
        router.push("/admin");
        router.refresh();
      } else {
        const data = await res.json().catch(() => ({}));
        setError(data.error || "Something went wrong");
        setSubmitting(false);
      }
    } catch {
      setError("Network error");
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="field">
        <label>Partner 1 name</label>
        <input
          type="text"
          value={partner1}
          onChange={(e) => setPartner1(e.target.value)}
          required
        />
      </div>
      <div className="field">
        <label>Partner 2 name</label>
        <input
          type="text"
          value={partner2}
          onChange={(e) => setPartner2(e.target.value)}
          required
        />
      </div>
      <div className="field">
        <label>Wedding date (optional)</label>
        <input
          type="date"
          value={weddingDate}
          onChange={(e) => setWeddingDate(e.target.value)}
        />
      </div>
      <div className="field">
        <label>Theme</label>
        <select value={theme} onChange={(e) => setTheme(e.target.value)}>
          {THEMES.map((t) => (
            <option key={t.key} value={t.key}>
              {t.label}
            </option>
          ))}
        </select>
      </div>
      <div className="field">
        <label>Welcome message (optional)</label>
        <textarea
          value={welcomeMessage}
          onChange={(e) => setWelcomeMessage(e.target.value)}
        />
      </div>
      <div className="field">
        <label>Admin password (min 6 characters)</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={6}
        />
      </div>
      {error && <p style={{ color: "crimson" }}>{error}</p>}
      <button
        type="submit"
        className="btn btn-primary btn-block"
        disabled={submitting}
      >
        {submitting ? "Setting up…" : "Create registry"}
      </button>
    </form>
  );
}
