import { redirect } from "next/navigation";
import { isSetupComplete } from "@/lib/config";
import SetupForm from "./SetupForm";

export const dynamic = "force-dynamic";

export default async function SetupPage() {
  if (await isSetupComplete()) redirect("/");

  return (
    <main className="container" style={{ maxWidth: "560px", padding: "3rem 0" }}>
      <div className="center stack">
        <h1>Welcome</h1>
        <p className="muted">
          Let&apos;s set up your wedding registry. You can change any of this
          later from the admin.
        </p>
      </div>
      <div className="card" style={{ padding: "1.75rem", marginTop: "2rem" }}>
        <SetupForm />
      </div>
    </main>
  );
}
