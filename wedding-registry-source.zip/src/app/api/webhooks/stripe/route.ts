import { NextResponse } from "next/server";
import { optionalImport } from "@/lib/optionalImport";
import { recordPaidContribution } from "@/lib/payments";

export const runtime = "nodejs";

// Stripe webhook: verifies the signature, and when a Checkout payment completes
// records the paid contribution. Only used when PAYMENT_PROVIDER=stripe.
export async function POST(req: Request) {
  const key = process.env.STRIPE_SECRET_KEY;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!key || !webhookSecret) {
    return NextResponse.json(
      { error: "Stripe is not configured" },
      { status: 400 }
    );
  }

  const signature = req.headers.get("stripe-signature");
  if (!signature) {
    return NextResponse.json({ error: "Missing signature" }, { status: 400 });
  }

  // The raw body is required for signature verification.
  const rawBody = await req.text();

  let event: any;
  try {
    const mod = await optionalImport("stripe");
    const Stripe = mod.default;
    const stripe = new Stripe(key);
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data?.object ?? {};
    const m = session.metadata ?? {};
    const itemId = String(m.itemId ?? "");

    if (itemId) {
      try {
        await recordPaidContribution({
          itemId,
          guestName: String(m.guestName ?? "Guest"),
          message: m.message ? String(m.message) : null,
          contact: m.contact ? String(m.contact) : null,
          amountCents: Number(m.amountCents) || 0,
          providerRef:
            (session.payment_intent as string) ||
            (session.id as string) ||
            null,
        });
      } catch (err) {
        console.error("Error recording paid contribution:", err);
      }
    }
  }

  return NextResponse.json({ received: true });
}
