import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { optionalImport } from "@/lib/optionalImport";
import { isCardPaymentEnabled } from "@/lib/payments";

export const runtime = "nodejs";

const STRIPE_MIN_CENTS = 50;

// Public: starts a Stripe Checkout session so a guest can pay a cash gift by
// card. Returns the hosted Checkout URL; the browser redirects there.
export async function POST(req: Request) {
  if (!isCardPaymentEnabled()) {
    return NextResponse.json(
      { error: "Card payments are not enabled" },
      { status: 400 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const itemId = String(body.itemId ?? "").trim();
  const guestName = String(body.guestName ?? "").trim();
  if (!itemId || !guestName) {
    return NextResponse.json(
      { error: "Your name and the item are required" },
      { status: 400 }
    );
  }

  const item = await prisma.item.findUnique({ where: { id: itemId } });
  if (!item) {
    return NextResponse.json({ error: "Item not found" }, { status: 404 });
  }
  if (!item.isCashGift) {
    return NextResponse.json(
      { error: "This item can't be paid by card" },
      { status: 400 }
    );
  }

  const amountCents = Math.round((Number(body.amount) || 0) * 100);
  if (amountCents < STRIPE_MIN_CENTS) {
    return NextResponse.json(
      { error: "Minimum card payment is $0.50" },
      { status: 400 }
    );
  }

  const message = String(body.message ?? "").trim();
  const contact = String(body.contact ?? "").trim();
  const origin = new URL(req.url).origin;

  try {
    const mod = await optionalImport("stripe");
    const Stripe = mod.default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string);

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: process.env.STRIPE_CURRENCY || "usd",
            product_data: { name: item.name },
            unit_amount: amountCents,
          },
          quantity: 1,
        },
      ],
      success_url: `${origin}/registry?thanks=1`,
      cancel_url: `${origin}/registry`,
      metadata: {
        itemId,
        guestName,
        message,
        contact,
        amountCents: String(amountCents),
      },
    });

    return NextResponse.json({ url: session.url });
  } catch {
    return NextResponse.json(
      { error: "Could not start checkout" },
      { status: 500 }
    );
  }
}
