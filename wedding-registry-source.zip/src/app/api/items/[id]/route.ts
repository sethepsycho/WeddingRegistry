import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Params) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const data: {
    name?: string;
    description?: string | null;
    priceCents?: number;
    photoUrl?: string | null;
    category?: string | null;
    allowPartial?: boolean;
    isCashGift?: boolean;
  } = {};

  if (typeof body.name !== "undefined") {
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }
    data.name = name;
  }

  if (typeof body.price !== "undefined") {
    data.priceCents = Math.max(0, Math.round((Number(body.price) || 0) * 100));
  }

  if (typeof body.description !== "undefined") {
    data.description = String(body.description ?? "").trim() || null;
  }

  if (typeof body.photoUrl !== "undefined") {
    data.photoUrl = String(body.photoUrl ?? "").trim() || null;
  }

  if (typeof body.category !== "undefined") {
    data.category = String(body.category ?? "").trim() || null;
  }

  if (typeof body.allowPartial !== "undefined") {
    data.allowPartial = Boolean(body.allowPartial);
  }

  if (typeof body.isCashGift !== "undefined") {
    data.isCashGift = Boolean(body.isCashGift);
    // A cash gift must accept amount-based contributions.
    if (data.isCashGift) data.allowPartial = true;
  }

  try {
    const item = await prisma.item.update({ where: { id }, data });
    return NextResponse.json({ item });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json({ error: "Item not found" }, { status: 404 });
    }
    return NextResponse.json({ error: "Failed to update item" }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: Params) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  try {
    // Claims and any associated Payment cascade via the Prisma schema.
    await prisma.item.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json({ error: "Item not found" }, { status: 404 });
    }
    return NextResponse.json({ error: "Failed to delete item" }, { status: 500 });
  }
}
