import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";

export async function POST(req: Request) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const name = String(body.name ?? "").trim();
  if (!name) {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }

  const priceCents = Math.max(0, Math.round((Number(body.price) || 0) * 100));
  const description = String(body.description ?? "").trim() || null;
  const photoUrl = String(body.photoUrl ?? "").trim() || null;
  const category = String(body.category ?? "").trim() || null;
  const isCashGift = Boolean(body.isCashGift);
  // A cash gift is inherently amount-based, and is received as cash — so its
  // contributions auto-record a pledge (see the contributions route).
  const allowPartial = Boolean(body.allowPartial) || isCashGift;

  try {
    const item = await prisma.item.create({
      data: {
        name,
        description,
        priceCents,
        photoUrl,
        category,
        allowPartial,
        isCashGift,
        ...(isCashGift ? { fulfillment: "cash" } : {}),
      },
    });
    return NextResponse.json({ item }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to create item" }, { status: 500 });
  }
}
