import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, setAdminSession } from "@/lib/auth";
import { normalizeTheme } from "@/lib/themes";

const MIN_PASSWORD_LENGTH = 6;

export async function POST(req: Request) {
  try {
    const existing = await prisma.couple.findFirst();
    if (existing?.setupComplete) {
      return NextResponse.json(
        { error: "Setup already completed" },
        { status: 403 }
      );
    }

    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid request body" },
        { status: 400 }
      );
    }

    const partner1 = String(body.partner1 ?? "").trim();
    const partner2 = String(body.partner2 ?? "").trim();
    const adminPassword = String(body.adminPassword ?? "");
    const theme = normalizeTheme(String(body.theme ?? ""));
    const welcomeMessageRaw = String(body.welcomeMessage ?? "").trim();
    const weddingDateRaw = String(body.weddingDate ?? "").trim();

    if (!partner1 || !partner2) {
      return NextResponse.json(
        { error: "Both partner names are required" },
        { status: 400 }
      );
    }
    if (adminPassword.length < MIN_PASSWORD_LENGTH) {
      return NextResponse.json(
        {
          error: `Admin password must be at least ${MIN_PASSWORD_LENGTH} characters long`,
        },
        { status: 400 }
      );
    }

    let weddingDate: Date | null = null;
    if (weddingDateRaw) {
      const parsed = new Date(weddingDateRaw);
      if (isNaN(parsed.getTime())) {
        return NextResponse.json(
          { error: "Invalid wedding date" },
          { status: 400 }
        );
      }
      weddingDate = parsed;
    }

    const adminPasswordHash = await hashPassword(adminPassword);

    const data = {
      setupComplete: true,
      adminPasswordHash,
      partner1,
      partner2,
      weddingDate,
      theme,
      welcomeMessage: welcomeMessageRaw || null,
    };

    if (existing) {
      await prisma.couple.update({ where: { id: existing.id }, data });
    } else {
      await prisma.couple.create({ data });
    }

    await setAdminSession();
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Setup failed" }, { status: 500 });
  }
}
