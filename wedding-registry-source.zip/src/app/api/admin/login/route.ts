import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword, setAdminSession } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid request body" },
        { status: 400 }
      );
    }

    const password = String(body.password ?? "");

    const couple = await prisma.couple.findFirst();
    if (!couple || !couple.setupComplete) {
      return NextResponse.json(
        { error: "Registry is not set up yet" },
        { status: 400 }
      );
    }

    const ok = await verifyPassword(password, couple.adminPasswordHash);
    if (!ok) {
      return NextResponse.json(
        { error: "Incorrect password" },
        { status: 401 }
      );
    }

    await setAdminSession();
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Login failed" }, { status: 500 });
  }
}
