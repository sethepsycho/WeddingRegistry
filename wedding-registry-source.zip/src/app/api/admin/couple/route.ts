import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";
import { normalizeTheme } from "@/lib/themes";

export async function PATCH(req: Request) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const couple = await prisma.couple.findFirst();
  if (!couple) {
    return NextResponse.json({ error: "Couple not found" }, { status: 404 });
  }

  const data: Record<string, unknown> = {};

  if (typeof body.partner1 !== "undefined") {
    const partner1 = String(body.partner1 ?? "").trim();
    if (partner1 === "") {
      return NextResponse.json(
        { error: "Partner name cannot be empty" },
        { status: 400 }
      );
    }
    data.partner1 = partner1;
  }

  if (typeof body.partner2 !== "undefined") {
    const partner2 = String(body.partner2 ?? "").trim();
    if (partner2 === "") {
      return NextResponse.json(
        { error: "Partner name cannot be empty" },
        { status: 400 }
      );
    }
    data.partner2 = partner2;
  }

  if (typeof body.theme !== "undefined") {
    data.theme = normalizeTheme(String(body.theme ?? ""));
  }

  if (typeof body.welcomeMessage !== "undefined") {
    data.welcomeMessage = String(body.welcomeMessage ?? "").trim() || null;
  }

  if (typeof body.mailingAddress !== "undefined") {
    data.mailingAddress = String(body.mailingAddress ?? "").trim() || null;
  }

  if (typeof body.notifyEmail !== "undefined") {
    data.notifyEmail = String(body.notifyEmail ?? "").trim() || null;
  }

  if (typeof body.rsvpEnabled !== "undefined") {
    data.rsvpEnabled = Boolean(body.rsvpEnabled);
  }

  if (typeof body.rsvpDefaultMaxParty !== "undefined") {
    const n = Math.round(Number(body.rsvpDefaultMaxParty) || 1);
    data.rsvpDefaultMaxParty = Math.min(20, Math.max(1, n));
  }

  if (typeof body.weddingDate !== "undefined") {
    const weddingDateStr = String(body.weddingDate ?? "");
    if (weddingDateStr === "") {
      data.weddingDate = null;
    } else {
      const d = new Date(weddingDateStr);
      if (isNaN(d.getTime())) {
        return NextResponse.json(
          { error: "Invalid wedding date" },
          { status: 400 }
        );
      }
      data.weddingDate = d;
    }
  }

  try {
    const updated = await prisma.couple.update({
      where: { id: couple.id },
      data,
    });
    return NextResponse.json({ ok: true, couple: updated });
  } catch {
    return NextResponse.json(
      { error: "Failed to update settings" },
      { status: 500 }
    );
  }
}
