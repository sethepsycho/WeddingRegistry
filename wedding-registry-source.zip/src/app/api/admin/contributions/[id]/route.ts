import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";
import { recordCashPledge } from "@/lib/payments";

// Toggle thank-you status for a single contribution.
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  if (typeof body.thankYouSent === "undefined") {
    return NextResponse.json(
      { error: "Nothing to update" },
      { status: 400 }
    );
  }

  const thankYouSent = Boolean(body.thankYouSent);

  try {
    const contribution = await prisma.contribution.update({
      where: { id },
      data: {
        thankYouSent,
        // Stamp the time when marking sent; clear it when un-marking.
        thankYouAt: thankYouSent ? new Date() : null,
      },
    });
    return NextResponse.json({ contribution });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json(
        { error: "Contribution not found" },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { error: "Failed to update contribution" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  try {
    const contribution = await prisma.contribution.findUnique({ where: { id } });
    if (!contribution) {
      return NextResponse.json(
        { error: "Contribution not found" },
        { status: 404 }
      );
    }

    await prisma.contribution.delete({ where: { id } });

    // Resync an existing cash pledge to the remaining contributions.
    const item = await prisma.item.findUnique({
      where: { id: contribution.itemId },
    });
    if (item && item.fulfillment === "cash") {
      await recordCashPledge(contribution.itemId);
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json(
        { error: "Contribution not found" },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { error: "Failed to delete contribution" },
      { status: 500 }
    );
  }
}
