import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";

// Upper safety bound on a household's party size.
const MAX_ALLOWED_PARTY = 20;

function clampParty(value: unknown): number {
  const n = Math.round(Number(value) || 1);
  return Math.min(MAX_ALLOWED_PARTY, Math.max(1, n));
}

// Short, URL-safe secret code for the private RSVP link.
function newCode(): string {
  return randomBytes(9).toString("base64url");
}

export async function POST(req: Request) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const householdName = String(body.householdName ?? "").trim();
  if (!householdName) {
    return NextResponse.json(
      { error: "A name for the invitation is required" },
      { status: 400 }
    );
  }
  const maxPartySize = clampParty(body.maxPartySize);

  // Generate a unique code, retrying on the astronomically rare collision.
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      const invite = await prisma.invite.create({
        data: { householdName, maxPartySize, code: newCode() },
      });
      return NextResponse.json({ invite }, { status: 201 });
    } catch (error) {
      if ((error as { code?: string }).code === "P2002") continue; // code clash
      return NextResponse.json(
        { error: "Failed to add invite" },
        { status: 500 }
      );
    }
  }
  return NextResponse.json({ error: "Failed to add invite" }, { status: 500 });
}
