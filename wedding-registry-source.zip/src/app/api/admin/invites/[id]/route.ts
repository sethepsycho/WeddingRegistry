import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";

const MAX_ALLOWED_PARTY = 20;

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const data: { householdName?: string; maxPartySize?: number } = {};

  if (typeof body.householdName !== "undefined") {
    const householdName = String(body.householdName ?? "").trim();
    if (!householdName) {
      return NextResponse.json(
        { error: "A name for the invitation is required" },
        { status: 400 }
      );
    }
    data.householdName = householdName;
  }

  if (typeof body.maxPartySize !== "undefined") {
    const n = Math.round(Number(body.maxPartySize) || 1);
    data.maxPartySize = Math.min(MAX_ALLOWED_PARTY, Math.max(1, n));
  }

  try {
    const invite = await prisma.invite.update({ where: { id }, data });
    return NextResponse.json({ invite });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json({ error: "Invite not found" }, { status: 404 });
    }
    return NextResponse.json(
      { error: "Failed to update invite" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  try {
    // RSVPs that referenced this invite have their inviteId set to null
    // automatically (onDelete: SetNull in the schema).
    await prisma.invite.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json({ error: "Invite not found" }, { status: 404 });
    }
    return NextResponse.json(
      { error: "Failed to delete invite" },
      { status: 500 }
    );
  }
}
