import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";
import { recordCashPledge, removeCashPledge } from "@/lib/payments";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const item = await prisma.item.findUnique({ where: { id } });
  if (!item) {
    return NextResponse.json({ error: "Item not found" }, { status: 404 });
  }

  const data: {
    fulfillment?: string;
    giftReceived?: boolean;
    closed?: boolean;
  } = {};

  if (typeof body.fulfillment !== "undefined") {
    if (!["undecided", "gift", "cash"].includes(body.fulfillment as string)) {
      return NextResponse.json(
        { error: "Invalid fulfillment value" },
        { status: 400 }
      );
    }
    data.fulfillment = body.fulfillment as string;
  }

  if (typeof body.giftReceived !== "undefined") {
    data.giftReceived = Boolean(body.giftReceived);
  }

  if (typeof body.closed !== "undefined") {
    data.closed = Boolean(body.closed);
  }

  try {
    // Payment side effect follows the new fulfillment decision.
    if (data.fulfillment === "cash") {
      await recordCashPledge(id);
    } else if (data.fulfillment) {
      await removeCashPledge(id);
    }

    const updated = await prisma.item.update({ where: { id }, data });
    return NextResponse.json({ item: updated });
  } catch {
    return NextResponse.json(
      { error: "Failed to update item" },
      { status: 500 }
    );
  }
}
