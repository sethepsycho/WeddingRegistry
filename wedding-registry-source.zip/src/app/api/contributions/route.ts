import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { recordCashPledge } from "@/lib/payments";
import { notifyCouple } from "@/lib/email";
import { formatCents } from "@/lib/format";
import { fundedCents, remainingCents } from "@/lib/funding";
import { createRevealToken } from "@/lib/auth";

// Public endpoint: guests are anonymous. Handles both a whole-item "claim"
// and a partial group-gifting contribution, depending on the item.
export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const itemId = String(body.itemId ?? "").trim();
  const guestName = String(body.guestName ?? "").trim();
  const message = String(body.message ?? "").trim() || null;
  const guestContact = String(body.contact ?? "").trim() || null;
  const needsAddress = Boolean(body.needsAddress);

  if (!itemId || !guestName) {
    return NextResponse.json(
      { error: "Your name and the item are required" },
      { status: 400 }
    );
  }

  const item = await prisma.item.findUnique({
    where: { id: itemId },
    include: { contributions: true },
  });
  if (!item) {
    return NextResponse.json({ error: "Item not found" }, { status: 404 });
  }

  const funded = fundedCents(item);
  const remaining = remainingCents(item);

  if (item.closed) {
    return NextResponse.json(
      { error: "This gift is closed to further contributions" },
      { status: 409 }
    );
  }

  let amountCents: number;
  if (!item.allowPartial) {
    // Whole-item claim: one guest takes the entire item.
    if (item.contributions.length > 0) {
      return NextResponse.json(
        { error: "This item has already been claimed" },
        { status: 409 }
      );
    }
    amountCents = item.priceCents;
  } else {
    // Group gifting: a partial contribution.
    if (item.priceCents > 0 && funded >= item.priceCents) {
      return NextResponse.json(
        { error: "This gift is already fully funded" },
        { status: 409 }
      );
    }
    const dollars = Number(body.amount);
    if (!(dollars > 0)) {
      return NextResponse.json(
        { error: "Enter a valid contribution amount" },
        { status: 400 }
      );
    }
    amountCents = Math.round(dollars * 100);
    if (item.priceCents > 0 && amountCents > remaining) {
      amountCents = remaining; // don't overfund
    }
  }

  // The contribution itself is the only thing whose failure should 500.
  let created;
  try {
    created = await prisma.contribution.create({
      data: { itemId, guestName, message, amountCents, guestContact, needsAddress },
    });
  } catch {
    return NextResponse.json(
      { error: "Failed to submit contribution" },
      { status: 500 }
    );
  }

  // Side effects below run AFTER the contribution is safely persisted, so a
  // failure here must not turn a saved contribution into a 500 (which would
  // invite a duplicate resubmission).
  if (item.fulfillment === "cash") {
    try {
      await recordCashPledge(itemId);
    } catch (err) {
      console.error("[contributions] pledge sync failed:", err);
    }
  }

  // notifyCouple never throws (fire-and-forget).
  const verb = item.allowPartial
    ? `contributed ${formatCents(amountCents)} toward`
    : "claimed";
  await notifyCouple({
    subject: `New registry activity: ${item.name}`,
    text:
      `${guestName} ${verb} "${item.name}".` +
      (message ? `\n\nMessage: ${message}` : ""),
  });

  // Only a guest who opted into needing the address gets a (short-lived,
  // signed) token to reveal it — the address endpoint requires it.
  const addressToken = needsAddress
    ? createRevealToken(created.id) ?? undefined
    : undefined;

  return NextResponse.json({ ok: true, addressToken }, { status: 201 });
}
