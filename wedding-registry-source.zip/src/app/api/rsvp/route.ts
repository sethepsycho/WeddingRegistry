import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { notifyCouple } from "@/lib/email";

// Public endpoint: guests submit an RSVP (no auth).
export async function POST(request: Request) {
  const couple = await prisma.couple.findFirst({
    select: { setupComplete: true, rsvpEnabled: true, rsvpDefaultMaxParty: true },
  });
  if (!couple?.setupComplete) {
    return NextResponse.json(
      { error: "This registry isn't set up yet" },
      { status: 400 }
    );
  }
  if (!couple.rsvpEnabled) {
    return NextResponse.json({ error: "RSVPs are closed" }, { status: 403 });
  }

  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const guestName = String(body.guestName ?? "").trim();
  if (!guestName) {
    return NextResponse.json(
      { error: "Your name is required" },
      { status: 400 }
    );
  }

  // Resolve the party-size cap from the chosen invite (if any), else the
  // couple's default. An unknown/removed invite falls back to the default.
  const requestedInviteId = String(body.inviteId ?? "").trim() || null;
  let inviteId: string | null = null;
  let maxAllowed = couple.rsvpDefaultMaxParty;
  if (requestedInviteId) {
    const invite = await prisma.invite.findUnique({
      where: { id: requestedInviteId },
      select: { id: true, maxPartySize: true },
    });
    if (invite) {
      inviteId = invite.id;
      maxAllowed = invite.maxPartySize;
    }
  }

  const attending = Boolean(body.attending);
  let partySize = attending ? Math.round(Number(body.partySize) || 1) : 0;
  // Never let a guest exceed their allowance (or go below 1 when attending).
  partySize = Math.min(maxAllowed, Math.max(attending ? 1 : 0, partySize));

  const message = String(body.message ?? "").trim() || null;
  const contact = String(body.contact ?? "").trim() || null;

  try {
    await prisma.rsvp.create({
      data: { guestName, attending, partySize, message, contact, inviteId },
    });
    await notifyCouple({
      subject: `New RSVP: ${guestName}`,
      text:
        `${guestName} ${
          attending ? `is attending (party of ${partySize})` : "cannot attend"
        }.` + (message ? `\n\nMessage: ${message}` : ""),
    });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Failed to submit RSVP" },
      { status: 500 }
    );
  }
}
