import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";
import { isValidHttpUrl } from "@/lib/validation";

export async function POST(req: Request) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const label = String(body.label ?? "").trim();
  const url = String(body.url ?? "").trim();
  const storeName = String(body.storeName ?? "").trim() || null;

  if (!label) {
    return NextResponse.json({ error: "Label is required" }, { status: 400 });
  }
  if (!isValidHttpUrl(url)) {
    return NextResponse.json(
      { error: "Enter a valid http(s) URL" },
      { status: 400 }
    );
  }

  try {
    // Append new links after existing ones.
    const last = await prisma.externalLink.findFirst({
      orderBy: { sortOrder: "desc" },
      select: { sortOrder: true },
    });
    const sortOrder = (last?.sortOrder ?? -1) + 1;

    const link = await prisma.externalLink.create({
      data: { label, url, storeName, sortOrder },
    });
    return NextResponse.json({ link }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to add link" }, { status: 500 });
  }
}
