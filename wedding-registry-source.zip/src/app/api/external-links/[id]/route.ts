import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAdminAuthenticated } from "@/lib/auth";
import { isValidHttpUrl } from "@/lib/validation";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const data: Record<string, unknown> = {};

  if (typeof body.label !== "undefined") {
    const label = String(body.label ?? "").trim();
    if (!label) {
      return NextResponse.json({ error: "Label is required" }, { status: 400 });
    }
    data.label = label;
  }

  if (typeof body.url !== "undefined") {
    const url = String(body.url ?? "").trim();
    if (!isValidHttpUrl(url)) {
      return NextResponse.json(
        { error: "Enter a valid http(s) URL" },
        { status: 400 }
      );
    }
    data.url = url;
  }

  if (typeof body.storeName !== "undefined") {
    data.storeName = String(body.storeName ?? "").trim() || null;
  }

  try {
    const link = await prisma.externalLink.update({ where: { id }, data });
    return NextResponse.json({ link });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }
    return NextResponse.json(
      { error: "Failed to update link" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdminAuthenticated())) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;

  try {
    await prisma.externalLink.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    if ((error as { code?: string }).code === "P2025") {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }
    return NextResponse.json(
      { error: "Failed to delete link" },
      { status: 500 }
    );
  }
}
