import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCouple } from "@/lib/config";
import { verifyRevealToken } from "@/lib/auth";

// On-demand reveal of the couple's mailing address. Gated: the caller must
// present a valid, unexpired reveal token issued when they claimed a physical
// gift and opted to need the address. Never rendered into any page by default.
export async function GET(req: Request) {
  const token = new URL(req.url).searchParams.get("token") ?? "";
  const contributionId = verifyRevealToken(token);
  if (!contributionId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // The token must reference a real contribution that actually opted in.
  const contribution = await prisma.contribution.findUnique({
    where: { id: contributionId },
    select: { needsAddress: true },
  });
  if (!contribution?.needsAddress) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  }

  const couple = await getCouple();
  const address = couple?.mailingAddress?.trim() || null;
  return NextResponse.json({ address });
}
