"use client";

import { useState } from "react";

interface Invite {
  id: string;
  householdName: string;
  maxPartySize: number;
}

export default function RsvpForm({
  invite,
  defaultMaxParty,
}: {
  invite: Invite | null;
  defaultMaxParty: number;
}) {
  const [guestName, setGuestName] = useState("");
  const [attending, setAttending] = useState(true);
  const [partySize, setPartySize] = useState(1);
  const [message, setMessage] = useState("");
  const [contact, setContact] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  // The party-size cap comes from the guest's own private invite (matched by
  // the link they arrived with), or the couple's default if they have no link.
  const maxAllowed = invite ? invite.maxPartySize : defaultMaxParty;

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/rsvp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          guestName,
          inviteId: invite ? invite.id : null,
          attending,
          partySize,
          message,
          contact,
        }),
      });
      if (res.ok) {
        setDone(true);
      } else {
        const data = await res.json().catch(() => ({}));
        setError(data.error || "Something went wrong");
      }
    } catch {
      setError("Network error");
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <div className="center stack">
        <h3>Thank you!</h3>
        <p className="muted">Your RSVP has been received.</p>
      </div>
    );
  }

  const partyOptions = Array.from({ length: maxAllowed }, (_, i) => i + 1);

  return (
    <form onSubmit={handleSubmit}>
      {invite && (
        <p style={{ marginBottom: "1rem" }}>
          Responding for <strong>{invite.householdName}</strong>.
        </p>
      )}

      <div className="field">
        <label>Your name</label>
        <input
          type="text"
          value={guestName}
          onChange={(e) => setGuestName(e.target.value)}
          required
        />
      </div>

      <div className="field">
        <label>Will you attend?</label>
        <div style={{ display: "flex", gap: "0.5rem" }}>
          <button
            type="button"
            className={attending ? "btn btn-primary" : "btn btn-secondary"}
            onClick={() => setAttending(true)}
          >
            Joyfully accepts
          </button>
          <button
            type="button"
            className={!attending ? "btn btn-primary" : "btn btn-secondary"}
            onClick={() => setAttending(false)}
          >
            Regretfully declines
          </button>
        </div>
      </div>

      {attending &&
        (maxAllowed <= 1 ? (
          <p className="muted" style={{ marginBottom: "1rem" }}>
            This invitation is for 1 guest.
          </p>
        ) : (
          <div className="field">
            <label>How many in your party? (including you)</label>
            <select
              value={partySize}
              onChange={(e) => setPartySize(Number(e.target.value))}
            >
              {partyOptions.map((n) => (
                <option key={n} value={n}>
                  {n} {n === 1 ? "guest" : "guests"}
                </option>
              ))}
            </select>
            <p
              className="muted"
              style={{ fontSize: "0.8rem", marginTop: "0.3rem" }}
            >
              Up to {maxAllowed} — bring as few or as many as you like.
            </p>
          </div>
        ))}

      <div className="field">
        <label>Message (optional)</label>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
      </div>
      <div className="field">
        <label>Email or phone (optional)</label>
        <input
          type="text"
          value={contact}
          onChange={(e) => setContact(e.target.value)}
        />
      </div>
      {error && <p style={{ color: "crimson" }}>{error}</p>}
      <button
        type="submit"
        className="btn btn-primary btn-block"
        disabled={submitting}
      >
        {submitting ? "Sending…" : "Send RSVP"}
      </button>
    </form>
  );
}
