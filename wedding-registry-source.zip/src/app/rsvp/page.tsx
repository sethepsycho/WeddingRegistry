export const dynamic = "force-dynamic";

import { redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getPublicCouple } from "@/lib/config";
import SiteHeader from "@/components/SiteHeader";
import RsvpForm from "./RsvpForm";

export default async function RsvpPage({
  searchParams,
}: {
  searchParams: Promise<{ c?: string }>;
}) {
  const couple = await getPublicCouple();
  if (!couple || !couple.setupComplete) redirect("/setup");

  const coupleName = `${couple.partner1} & ${couple.partner2}`;

  // A guest reaches their invitation via a private link (/rsvp?c=CODE). We look
  // up ONLY their invite by code — the guest list is never listed publicly.
  const { c } = await searchParams;
  const code = typeof c === "string" ? c.trim() : "";
  const invite =
    code && couple.rsvpEnabled
      ? await prisma.invite.findUnique({
          where: { code },
          select: { id: true, householdName: true, maxPartySize: true },
        })
      : null;

  return (
    <>
      <SiteHeader coupleName={coupleName} />
      <main
        className="container"
        style={{ maxWidth: "560px", padding: "3rem 0" }}
      >
        {!couple.rsvpEnabled ? (
          <div className="center stack">
            <h1>RSVP</h1>
            <p className="muted">RSVPs aren&apos;t open right now.</p>
            <Link href="/" className="btn btn-secondary">
              Back home
            </Link>
          </div>
        ) : (
          <>
            <div className="center stack" style={{ marginBottom: "2rem" }}>
              <h1>RSVP</h1>
              <p className="muted">
                We can&apos;t wait to celebrate with you. Please let us know if
                you&apos;ll be there.
              </p>
            </div>
            <div className="card" style={{ padding: "1.75rem" }}>
              <RsvpForm
                invite={invite}
                defaultMaxParty={couple.rsvpDefaultMaxParty}
              />
            </div>
          </>
        )}
      </main>
    </>
  );
}
