"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatCents } from "@/lib/format";

interface ContributeModalProps {
  itemId: string;
  itemName: string;
  allowPartial: boolean;
  isCashGift: boolean;
  cardPaymentsEnabled: boolean;
  priceCents: number;
  remainingCents: number;
}

export default function ContributeModal({
  itemId,
  itemName,
  allowPartial,
  isCashGift,
  cardPaymentsEnabled,
  priceCents,
  remainingCents,
}: ContributeModalProps) {
  const [open, setOpen] = useState(false);
  const [guestName, setGuestName] = useState("");
  const [message, setMessage] = useState("");
  const [contact, setContact] = useState("");
  const [amount, setAmount] = useState("");
  const [needsAddress, setNeedsAddress] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [address, setAddress] = useState<string | null>(null);
  const [addressToken, setAddressToken] = useState<string | null>(null);
  const [revealing, setRevealing] = useState(false);

  const router = useRouter();
  const label = isCashGift
    ? "Give a cash gift"
    : allowPartial
    ? "Contribute"
    : "Claim this gift";
  const hasGoal = priceCents > 0;
  // Real card payment applies to cash gifts when Stripe Checkout is configured.
  const payByCard = isCashGift && cardPaymentsEnabled;

  function close() {
    setOpen(false);
    setGuestName("");
    setMessage("");
    setContact("");
    setAmount("");
    setNeedsAddress(false);
    setSubmitting(false);
    setError(null);
    setSubmitted(false);
    setAddress(null);
    setAddressToken(null);
    setRevealing(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    // Cash gift + Stripe configured: send the guest to Stripe's secure page.
    if (payByCard) {
      try {
        const res = await fetch("/api/checkout", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            itemId,
            guestName,
            message,
            contact,
            amount: Number(amount),
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.url) {
            window.location.href = data.url; // redirect to Stripe Checkout
            return;
          }
          setError("Could not start checkout");
        } else {
          const data = await res.json().catch(() => ({}));
          setError(data.error || "Could not start checkout");
        }
      } catch {
        setError("Network error");
      }
      setSubmitting(false);
      return;
    }

    try {
      const res = await fetch("/api/contributions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemId,
          guestName,
          message,
          contact,
          needsAddress: !allowPartial ? needsAddress : false,
          amount: allowPartial ? Number(amount) : undefined,
        }),
      });

      if (res.ok) {
        if (!allowPartial && needsAddress) {
          // Keep the modal open so the guest can reveal the address, using the
          // one-time token the API issued for this claim.
          const data = await res.json().catch(() => ({}));
          setAddressToken(
            typeof data.addressToken === "string" ? data.addressToken : null
          );
          setSubmitted(true);
          setSubmitting(false);
          router.refresh();
        } else {
          setOpen(false);
          setSubmitting(false);
          router.refresh();
        }
      } else {
        const data = await res.json().catch(() => ({}));
        setError(data.error || "Something went wrong");
        setSubmitting(false);
      }
    } catch {
      setError("Network error");
      setSubmitting(false);
    }
  }

  async function revealAddress() {
    setRevealing(true);
    try {
      const res = await fetch(
        "/api/address?token=" + encodeURIComponent(addressToken ?? "")
      );
      const data = await res.json().catch(() => ({}));
      setAddress(typeof data.address === "string" ? data.address : "");
    } catch {
      setAddress("");
    } finally {
      setRevealing(false);
    }
  }

  return (
    <>
      <button className="btn btn-primary btn-block" onClick={() => setOpen(true)}>
        {label}
      </button>
      {open && (
        <div className="modal-overlay" onClick={close}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            {submitted ? (
              <>
                <h3 style={{ marginBottom: "0.25rem" }}>
                  Thank you, {guestName}!
                </h3>
                <p
                  className="muted"
                  style={{ fontSize: "0.9rem", marginBottom: "1rem" }}
                >
                  You claimed &ldquo;{itemName}&rdquo; and asked for the
                  couple&apos;s mailing address.
                </p>
                {address === null && (
                  <button
                    className="btn btn-primary btn-block"
                    onClick={revealAddress}
                    disabled={revealing}
                  >
                    {revealing ? "Revealing…" : "Reveal mailing address"}
                  </button>
                )}
                {address === "" && (
                  <p className="muted">
                    The couple hasn&apos;t added a mailing address yet — please
                    reach out to them directly.
                  </p>
                )}
                {address && (
                  <div
                    className="card"
                    style={{
                      padding: "1rem",
                      whiteSpace: "pre-line",
                      marginBottom: "1rem",
                    }}
                  >
                    {address}
                  </div>
                )}
                <button
                  className="btn btn-secondary btn-block"
                  style={{ marginTop: "0.75rem" }}
                  onClick={close}
                >
                  Done
                </button>
              </>
            ) : (
              <>
                <h3 style={{ marginBottom: "0.25rem" }}>
                  {isCashGift
                    ? "Cash gift"
                    : allowPartial
                    ? "Contribute to"
                    : "Claim"}{" "}
                  &ldquo;{itemName}&rdquo;
                </h3>
                {isCashGift ? (
                  <p
                    className="muted"
                    style={{ fontSize: "0.9rem", marginBottom: "1rem" }}
                  >
                    This is an unrestricted cash gift — it goes straight to the
                    couple to use however they like, not a specific
                    &ldquo;fund.&rdquo;
                    {hasGoal &&
                      ` ${formatCents(remainingCents)} left toward their goal.`}
                    {payByCard
                      ? " You'll pay securely by card on the next screen."
                      : ""}
                  </p>
                ) : (
                  allowPartial && (
                    <p
                      className="muted"
                      style={{ fontSize: "0.9rem", marginBottom: "1rem" }}
                    >
                      {formatCents(remainingCents)} still needed. Contribute any
                      amount.
                    </p>
                  )
                )}
                <form onSubmit={handleSubmit}>
                  <div className="field">
                    <label>Your name</label>
                    <input
                      type="text"
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      required
                    />
                  </div>
                  {allowPartial && (
                    <div className="field">
                      <label>Amount (USD)</label>
                      <input
                        type="number"
                        min="1"
                        step="0.01"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        required
                        placeholder={
                          hasGoal
                            ? `Up to ${formatCents(remainingCents)}`
                            : "Any amount"
                        }
                      />
                    </div>
                  )}
                  <div className="field">
                    <label>Message (optional)</label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                    />
                  </div>
                  <div className="field">
                    <label>Email or phone (optional)</label>
                    <input
                      type="text"
                      value={contact}
                      onChange={(e) => setContact(e.target.value)}
                      placeholder="So the couple can send a thank-you"
                    />
                  </div>
                  {!allowPartial && (
                    <div className="field">
                      <label
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "0.5rem",
                        }}
                      >
                        <input
                          type="checkbox"
                          style={{ width: "auto" }}
                          checked={needsAddress}
                          onChange={(e) => setNeedsAddress(e.target.checked)}
                        />
                        I&apos;ll need the couple&apos;s mailing address to send
                        this gift
                      </label>
                    </div>
                  )}
                  {error && <p style={{ color: "crimson" }}>{error}</p>}
                  <div
                    style={{
                      display: "flex",
                      gap: "0.75rem",
                      justifyContent: "flex-end",
                    }}
                  >
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={close}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={submitting}
                    >
                      {submitting
                        ? payByCard
                          ? "Starting…"
                          : "Sending…"
                        : payByCard
                        ? "Pay by card"
                        : allowPartial
                        ? "Contribute"
                        : "Confirm claim"}
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
