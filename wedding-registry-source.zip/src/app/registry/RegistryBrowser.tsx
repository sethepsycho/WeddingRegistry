"use client";

import { useMemo, useState } from "react";
import { formatCents } from "@/lib/format";
import ContributeModal from "./ContributeModal";

export interface BrowserItem {
  id: string;
  name: string;
  description: string | null;
  priceCents: number;
  photoUrl: string | null;
  category: string | null;
  allowPartial: boolean;
  isCashGift: boolean;
  createdAtMs: number;
  fundedCents: number;
  percent: number;
  open: boolean; // guest can still contribute/claim
  fullyFunded: boolean;
  remainingCents: number;
}

export default function RegistryBrowser({
  items,
  cardPaymentsEnabled,
}: {
  items: BrowserItem[];
  cardPaymentsEnabled: boolean;
}) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"all" | "available" | "claimed">("all");
  const [category, setCategory] = useState("all");
  const [sort, setSort] = useState<
    "featured" | "newest" | "priceAsc" | "priceDesc"
  >("featured");

  const categories = useMemo(
    () =>
      Array.from(
        new Set(items.map((i) => i.category).filter((c): c is string => !!c))
      ).sort(),
    [items]
  );

  const visible = useMemo(() => {
    let filteredItems = items;

    if (query.trim()) {
      const q = query.trim().toLowerCase();
      filteredItems = filteredItems.filter((i) =>
        i.name.toLowerCase().includes(q)
      );
    }

    if (status === "available") {
      filteredItems = filteredItems.filter((i) => i.open);
    } else if (status === "claimed") {
      filteredItems = filteredItems.filter((i) => !i.open);
    }

    if (category !== "all") {
      filteredItems = filteredItems.filter((i) => i.category === category);
    }

    const sortedItems = [...filteredItems];
    switch (sort) {
      case "newest":
        sortedItems.sort((a, b) => b.createdAtMs - a.createdAtMs);
        break;
      case "priceAsc":
        sortedItems.sort((a, b) => a.priceCents - b.priceCents);
        break;
      case "priceDesc":
        sortedItems.sort((a, b) => b.priceCents - a.priceCents);
        break;
      default:
        // "featured" keeps the given order
        break;
    }

    return sortedItems;
  }, [items, query, status, category, sort]);

  return (
    <div>
      <div className="toolbar">
        <input
          type="search"
          className="toolbar-search"
          placeholder="Search gifts…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value as typeof status)}
        >
          <option value="all">All gifts</option>
          <option value="available">Available</option>
          <option value="claimed">Claimed</option>
        </select>
        {categories.length > 0 && (
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        )}
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as typeof sort)}
        >
          <option value="featured">Featured</option>
          <option value="newest">Newest</option>
          <option value="priceAsc">Price: low to high</option>
          <option value="priceDesc">Price: high to low</option>
        </select>
      </div>
      {visible.length === 0 ? (
        <p className="center muted">No gifts match your filters.</p>
      ) : (
        <div className="registry-grid">
          {visible.map((item) => (
            <article className="item-card" key={item.id}>
              {item.photoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  className="item-photo"
                  src={item.photoUrl}
                  alt={item.name}
                />
              ) : (
                <div className="item-photo" />
              )}
              <div className="item-body">
                <div className="item-title">{item.name}</div>
                <div style={{ display: "flex", gap: "0.4rem", flexWrap: "wrap" }}>
                  {item.isCashGift && (
                    <span className="badge">Cash gift</span>
                  )}
                  {item.category && (
                    <span className="badge">{item.category}</span>
                  )}
                </div>
                {item.description && (
                  <p className="muted" style={{ fontSize: "0.9rem" }}>
                    {item.description}
                  </p>
                )}
                {item.isCashGift && (
                  <p className="muted" style={{ fontSize: "0.82rem" }}>
                    An unrestricted cash gift — it goes straight to the couple to
                    use however they like.
                  </p>
                )}
                {/* Show a price only when there's a goal; open-ended cash gifts have none. */}
                {item.priceCents > 0 ? (
                  <div className="item-price">
                    {formatCents(item.priceCents)}
                    {item.isCashGift ? " goal" : ""}
                  </div>
                ) : (
                  item.isCashGift && (
                    <div className="item-price">Any amount</div>
                  )
                )}
                {item.allowPartial && item.priceCents > 0 ? (
                  <div style={{ marginTop: "0.5rem" }}>
                    <div className="progress-label">
                      <span>{formatCents(item.fundedCents)} raised</span>
                      <span>{item.percent}%</span>
                    </div>
                    <div className="progress">
                      <div
                        className="progress-bar"
                        style={{ width: item.percent + "%" }}
                      />
                    </div>
                  </div>
                ) : (
                  item.isCashGift &&
                  item.fundedCents > 0 && (
                    <div
                      className="muted"
                      style={{ fontSize: "0.85rem", marginTop: "0.4rem" }}
                    >
                      {formatCents(item.fundedCents)} contributed so far
                    </div>
                  )
                )}
                <div style={{ flex: 1 }} />
                {item.open ? (
                  <ContributeModal
                    itemId={item.id}
                    itemName={item.name}
                    allowPartial={item.allowPartial}
                    isCashGift={item.isCashGift}
                    cardPaymentsEnabled={cardPaymentsEnabled}
                    priceCents={item.priceCents}
                    remainingCents={item.remainingCents}
                  />
                ) : item.allowPartial && item.fullyFunded ? (
                  <span className="badge">Fully funded</span>
                ) : (
                  <span className="badge">Claimed</span>
                )}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
