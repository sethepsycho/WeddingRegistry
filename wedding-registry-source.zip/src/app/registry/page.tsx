import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getPublicCouple } from "@/lib/config";
import {
  fundedCents,
  remainingCents,
  isFullyFunded,
  canContribute,
  fundedPercent,
} from "@/lib/funding";
import { isCardPaymentEnabled } from "@/lib/payments";
import SiteHeader from "@/components/SiteHeader";
import RegistryBrowser, { BrowserItem } from "./RegistryBrowser";

export const dynamic = "force-dynamic";

export default async function RegistryPage({
  searchParams,
}: {
  searchParams: Promise<{ thanks?: string }>;
}) {
  const couple = await getPublicCouple();
  if (!couple || !couple.setupComplete) {
    redirect("/setup");
  }

  const { thanks } = await searchParams;
  const cardPaymentsEnabled = isCardPaymentEnabled();

  // Only contribution AMOUNTS are loaded — never contributor identities.
  const [items, externalLinks] = await Promise.all([
    prisma.item.findMany({
      orderBy: { createdAt: "asc" },
      include: { contributions: { select: { amountCents: true } } },
    }),
    prisma.externalLink.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    }),
  ]);

  const coupleName = `${couple.partner1} & ${couple.partner2}`;

  // Serializable, guest-safe view of each item for the client browser.
  const browserItems: BrowserItem[] = items.map((i) => ({
    id: i.id,
    name: i.name,
    description: i.description,
    priceCents: i.priceCents,
    photoUrl: i.photoUrl,
    category: i.category,
    allowPartial: i.allowPartial,
    isCashGift: i.isCashGift,
    createdAtMs: i.createdAt.getTime(),
    fundedCents: fundedCents(i),
    percent: fundedPercent(i),
    open: canContribute(i),
    fullyFunded: isFullyFunded(i),
    remainingCents: remainingCents(i),
  }));

  return (
    <>
      <SiteHeader
        coupleName={coupleName}
        showRegistryLink={false}
        showRsvpLink={couple.rsvpEnabled}
      />
      <main className="container" style={{ padding: "2.5rem 0" }}>
        <div className="center stack" style={{ marginBottom: "2rem" }}>
          <h1>Our Registry</h1>
          <p className="muted">
            Claim a gift, or chip in together — no account needed.
          </p>
        </div>

        {thanks && (
          <div
            className="card center"
            style={{
              padding: "1rem 1.25rem",
              marginBottom: "1.5rem",
              borderColor: "var(--accent)",
            }}
          >
            Thank you so much for your gift! 💛
          </div>
        )}

        {browserItems.length === 0 ? (
          <p className="center muted">No items yet. Check back soon!</p>
        ) : (
          <RegistryBrowser
            items={browserItems}
            cardPaymentsEnabled={cardPaymentsEnabled}
          />
        )}

        {externalLinks.length > 0 && (
          <section style={{ marginTop: "3.5rem" }}>
            <div className="center" style={{ marginBottom: "1.5rem" }}>
              <h2>Also registered at</h2>
              <p className="muted">A few of our gifts live on other registries.</p>
            </div>
            <div
              className="stack"
              style={{ maxWidth: "640px", margin: "0 auto" }}
            >
              {externalLinks.map((link) => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="card"
                  style={{
                    padding: "1rem 1.25rem",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: "1rem",
                    color: "var(--text)",
                    textDecoration: "none",
                  }}
                >
                  <span>
                    <strong>{link.label}</strong>
                    {link.storeName && (
                      <span className="muted"> · {link.storeName}</span>
                    )}
                  </span>
                  <span aria-hidden="true" style={{ color: "var(--accent)" }}>
                    ↗
                  </span>
                </a>
              ))}
            </div>
          </section>
        )}
      </main>
    </>
  );
}
