"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function LogoutButton() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function handleLogout() {
    setBusy(true);
    try {
      await fetch("/api/admin/logout", { method: "POST" });
      router.push("/");
      router.refresh();
    } catch {
      setBusy(false);
    }
  }

  return (
    <button className="btn btn-secondary" disabled={busy} onClick={handleLogout}>
      Log out
    </button>
  );
}
