"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export interface AdminInvite {
  id: string;
  householdName: string;
  maxPartySize: number;
  code: string;
}

export default function AdminInvites({ invites }: { invites: AdminInvite[] }) {
  const router = useRouter();
  const [householdName, setHouseholdName] = useState("");
  const [maxPartySize, setMaxPartySize] = useState("2");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editMax, setEditMax] = useState("2");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  async function copyLink(invite: AdminInvite) {
    const url = `${window.location.origin}/rsvp?c=${invite.code}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      // Clipboard may be blocked; fall back to a prompt the couple can copy from.
      window.prompt("Copy this private RSVP link:", url);
    }
    setCopiedId(invite.id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  async function addInvite(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/invites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          householdName,
          maxPartySize: Number(maxPartySize),
        }),
      });
      if (res.ok) {
        setHouseholdName("");
        setMaxPartySize("2");
        router.refresh();
      } else {
        setError((await res.json().catch(() => ({}))).error || "Failed to add");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  function startEdit(invite: AdminInvite) {
    setEditingId(invite.id);
    setEditName(invite.householdName);
    setEditMax(String(invite.maxPartySize));
  }
  const cancelEdit = () => setEditingId(null);

  async function saveEdit(id: string) {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/invites/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          householdName: editName,
          maxPartySize: Number(editMax),
        }),
      });
      if (res.ok) {
        setEditingId(null);
        router.refresh();
      } else {
        setError((await res.json().catch(() => ({}))).error || "Failed to save");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  async function deleteInvite(id: string) {
    if (!confirm("Remove this invitation from the guest list?")) return;
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/invites/${id}`, { method: "DELETE" });
      if (res.ok) {
        router.refresh();
      } else {
        setError(
          (await res.json().catch(() => ({}))).error || "Failed to delete"
        );
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section style={{ marginTop: "2.5rem" }}>
      <h2>Guest list &amp; party limits</h2>
      <p className="muted" style={{ marginTop: "0.25rem" }}>
        Add each invitation and how many people it may bring (e.g. &ldquo;Jane +
        guest&rdquo; = 2, &ldquo;The Smith Family&rdquo; = 5). Each one gets a
        private RSVP link — click <strong>Copy link</strong> and share it with
        that household (on their invitation). They&apos;ll only ever see their own
        invitation, and can bring up to — but never have to fill — the limit. Your
        guest list stays private. Anyone RSVPing without a link uses the default
        in Couple &amp; event.
      </p>

      <div className="card" style={{ padding: "1.25rem", marginTop: "1rem" }}>
        <form onSubmit={addInvite}>
          <div className="field">
            <label>Invitation name (household or guest)</label>
            <input
              type="text"
              value={householdName}
              onChange={(e) => setHouseholdName(e.target.value)}
              placeholder="e.g. The Smith Family"
              required
            />
          </div>
          <div className="field">
            <label>People allowed (max party size)</label>
            <input
              type="number"
              min="1"
              max="20"
              value={maxPartySize}
              onChange={(e) => setMaxPartySize(e.target.value)}
              required
            />
          </div>
          <button className="btn btn-primary" disabled={busy}>
            Add to guest list
          </button>
        </form>
      </div>

      {error && <p style={{ color: "crimson" }}>{error}</p>}

      {invites.length === 0 ? (
        <p className="muted" style={{ marginTop: "1.5rem" }}>
          No invitations yet. Everyone uses the default party limit until you add
          some.
        </p>
      ) : (
        <div className="stack" style={{ marginTop: "1.5rem" }}>
          {invites.map((invite) => (
            <div
              key={invite.id}
              className="card"
              style={{
                padding: "1rem",
                display: "flex",
                gap: "1rem",
                justifyContent: "space-between",
                alignItems: "flex-start",
              }}
            >
              {editingId === invite.id ? (
                <div className="stack" style={{ flex: 1 }}>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    required
                  />
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={editMax}
                    onChange={(e) => setEditMax(e.target.value)}
                    required
                  />
                  <div style={{ display: "flex", gap: "0.5rem" }}>
                    <button
                      className="btn btn-primary"
                      onClick={() => saveEdit(invite.id)}
                      disabled={busy}
                    >
                      Save
                    </button>
                    <button className="btn btn-secondary" onClick={cancelEdit}>
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div>
                    <strong>{invite.householdName}</strong>
                    <div className="muted">
                      Up to {invite.maxPartySize}{" "}
                      {invite.maxPartySize === 1 ? "guest" : "guests"}
                    </div>
                    <div
                      className="muted"
                      style={{
                        fontSize: "0.8rem",
                        marginTop: "0.2rem",
                        wordBreak: "break-all",
                      }}
                    >
                      Private link: /rsvp?c={invite.code}
                    </div>
                  </div>
                  <div
                    style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}
                  >
                    <button
                      className="btn btn-secondary"
                      onClick={() => copyLink(invite)}
                    >
                      {copiedId === invite.id ? "Copied!" : "Copy link"}
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => startEdit(invite)}
                    >
                      Edit
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => deleteInvite(invite.id)}
                    >
                      Delete
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
