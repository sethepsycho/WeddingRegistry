"use client";

import { formatCents } from "@/lib/format";
import { useState } from "react";
import { useRouter } from "next/navigation";

export interface AdminContribution {
  id: string;
  guestName: string;
  message: string | null;
  amountCents: number;
  needsAddress: boolean;
  createdAtLabel: string;
}

export interface AdminFundingItem {
  id: string;
  name: string;
  priceCents: number;
  allowPartial: boolean;
  closed: boolean;
  fulfillment: "undecided" | "gift" | "cash";
  giftReceived: boolean;
  fundedCents: number;
  percent: number;
  fullyFunded: boolean;
  pledgeAmountCents: number | null;
  contributions: AdminContribution[];
}

export default function AdminFunding({ items }: { items: AdminFundingItem[] }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const patchItem = async (id: string, body: object) => {
    setBusyId(id);
    setError(null);
    try {
      const res = await fetch(`/api/admin/items/${id}/fulfillment`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        router.refresh();
      } else {
        setError((await res.json().catch(() => ({}))).error || "Update failed");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusyId(null);
    }
  };

  const removeContribution = async (id: string) => {
    if (!confirm("Remove this contribution?")) return;
    setBusyId(id);
    setError(null);
    try {
      const res = await fetch(`/api/admin/contributions/${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        router.refresh();
      } else {
        setError((await res.json().catch(() => ({}))).error || "Delete failed");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <section style={{ marginTop: "2.5rem" }}>
      <h2>Claims &amp; funding</h2>
      <p className="muted" style={{ marginTop: "0.25rem" }}>
        Only you can see this. Choose how to receive each gift; for group gifts
        you can close funding early.
      </p>
      {error && <p style={{ color: "crimson" }}>{error}</p>}
      {items.length === 0 ? (
        <p className="muted" style={{ marginTop: "1rem" }}>
          No claims yet.
        </p>
      ) : (
        <div className="stack" style={{ marginTop: "1rem" }}>
          {items.map((item) => {
            const status = item.closed
              ? "Closed"
              : item.allowPartial
              ? item.fullyFunded
                ? "Fully funded"
                : "Funding"
              : "Claimed";

            return (
              <div key={item.id} className="card" style={{ padding: "1rem" }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "1rem",
                    flexWrap: "wrap",
                    alignItems: "baseline",
                  }}
                >
                  <div>
                    <strong>{item.name}</strong>{" "}
                    <span className="badge" style={{ marginLeft: "0.5rem" }}>
                      {status}
                    </span>
                  </div>
                  <div className="muted">
                    {formatCents(item.fundedCents)} of{" "}
                    {formatCents(item.priceCents)}
                  </div>
                </div>
                {item.allowPartial && (
                  <div style={{ marginTop: "0.6rem" }}>
                    <div className="progress">
                      <div
                        className="progress-bar"
                        style={{ width: item.percent + "%" }}
                      />
                    </div>
                  </div>
                )}
                <div className="stack" style={{ marginTop: "0.85rem" }}>
                  {item.contributions.length > 0 ? (
                    item.contributions.map((c) => (
                      <div
                        key={c.id}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          gap: "0.75rem",
                          fontSize: "0.9rem",
                          borderTop: "1px solid var(--border)",
                          paddingTop: "0.5rem",
                        }}
                      >
                        <div>
                          <strong>{c.guestName}</strong> ·{" "}
                          {formatCents(c.amountCents)}{" "}
                          <span className="muted">· {c.createdAtLabel}</span>
                          {c.needsAddress && (
                            <span
                              className="badge"
                              style={{ marginLeft: "0.5rem" }}
                            >
                              Needs your address
                            </span>
                          )}
                          {c.message && (
                            <div
                              className="muted"
                              style={{ fontStyle: "italic" }}
                            >
                              &ldquo;{c.message}&rdquo;
                            </div>
                          )}
                        </div>
                        <button
                          className="btn btn-secondary"
                          disabled={busyId === item.id}
                          onClick={() => removeContribution(c.id)}
                        >
                          Remove
                        </button>
                      </div>
                    ))
                  ) : (
                    <p className="muted" style={{ fontSize: "0.85rem" }}>
                      No contributions yet.
                    </p>
                  )}
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: "0.5rem",
                    alignItems: "center",
                    flexWrap: "wrap",
                    marginTop: "0.85rem",
                  }}
                >
                  {[
                    { value: "undecided", label: "Undecided" },
                    { value: "gift", label: "Receive as gift" },
                    { value: "cash", label: "Prefer the cash" },
                  ].map(({ value, label }) => (
                    <button
                      key={value}
                      className={
                        item.fulfillment === value
                          ? "btn btn-primary"
                          : "btn btn-secondary"
                      }
                      disabled={busyId === item.id}
                      onClick={() => patchItem(item.id, { fulfillment: value })}
                    >
                      {label}
                    </button>
                  ))}
                  {item.fulfillment === "gift" && (
                    <label
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "0.4rem",
                        marginLeft: "0.5rem",
                      }}
                    >
                      <input
                        type="checkbox"
                        style={{ width: "auto" }}
                        checked={item.giftReceived}
                        disabled={busyId === item.id}
                        onChange={(e) =>
                          patchItem(item.id, { giftReceived: e.target.checked })
                        }
                      />
                      Received
                    </label>
                  )}
                  {item.fulfillment === "cash" &&
                    item.pledgeAmountCents != null && (
                      <span className="badge">
                        Pledged {formatCents(item.pledgeAmountCents)}
                      </span>
                    )}
                  <div style={{ flex: 1 }} />
                  <button
                    className="btn btn-secondary"
                    disabled={busyId === item.id}
                    onClick={() => patchItem(item.id, { closed: !item.closed })}
                  >
                    {item.closed ? "Reopen" : "Close funding"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
