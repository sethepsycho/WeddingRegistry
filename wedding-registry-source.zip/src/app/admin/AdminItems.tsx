"use client";

import { formatCents } from "@/lib/format";
import { useState } from "react";
import { useRouter } from "next/navigation";

export interface AdminItem {
  id: string;
  name: string;
  description: string | null;
  priceCents: number;
  photoUrl: string | null;
  category: string | null;
  allowPartial: boolean;
  isCashGift: boolean;
}

export default function AdminItems({
  items,
  uploadsEnabled,
}: {
  items: AdminItem[];
  uploadsEnabled: boolean;
}) {
  const router = useRouter();
  const [uploading, setUploading] = useState(false);

  async function uploadFile(file: File, setUrl: (u: string) => void) {
    setUploading(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      if (res.ok) {
        const data = await res.json();
        setUrl(data.url);
      } else {
        setError(
          (await res.json().catch(() => ({}))).error || "Upload failed"
        );
      }
    } catch {
      setError("Network error");
    } finally {
      setUploading(false);
    }
  }
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [category, setCategory] = useState("");
  const [allowPartial, setAllowPartial] = useState(false);
  const [isCashGift, setIsCashGift] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editPrice, setEditPrice] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editPhotoUrl, setEditPhotoUrl] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const [editAllowPartial, setEditAllowPartial] = useState(false);
  const [editIsCashGift, setEditIsCashGift] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const addItem = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);

    try {
      const res = await fetch("/api/items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          price: Number(price),
          description,
          photoUrl,
          category,
          allowPartial,
          isCashGift,
        }),
      });

      if (res.ok) {
        setName("");
        setPrice("");
        setDescription("");
        setPhotoUrl("");
        setCategory("");
        setAllowPartial(false);
        setIsCashGift(false);
        router.refresh();
      } else {
        setError(
          (await res.json().catch(() => ({}))).error || "Failed to add item"
        );
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  };

  const startEdit = (item: AdminItem) => {
    setEditingId(item.id);
    setEditName(item.name);
    setEditPrice(String(item.priceCents / 100));
    setEditDescription(item.description || "");
    setEditPhotoUrl(item.photoUrl || "");
    setEditCategory(item.category || "");
    setEditAllowPartial(item.allowPartial);
    setEditIsCashGift(item.isCashGift);
  };

  const cancelEdit = () => setEditingId(null);

  const saveEdit = async (id: string) => {
    setBusy(true);
    setError(null);

    try {
      const res = await fetch(`/api/items/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: editName,
          price: Number(editPrice),
          description: editDescription,
          photoUrl: editPhotoUrl,
          category: editCategory,
          allowPartial: editAllowPartial,
          isCashGift: editIsCashGift,
        }),
      });

      if (res.ok) {
        setEditingId(null);
        router.refresh();
      } else {
        setError(
          (await res.json().catch(() => ({}))).error || "Failed to update item"
        );
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  };

  const deleteItem = async (id: string) => {
    if (
      !confirm(
        "Delete this item? This also removes any claims/contributions on it."
      )
    ) {
      return;
    }

    try {
      const res = await fetch(`/api/items/${id}`, { method: "DELETE" });
      if (res.ok) {
        router.refresh();
      } else {
        setError(
          (await res.json().catch(() => ({}))).error || "Failed to delete item"
        );
      }
    } catch {
      setError("Network error");
    }
  };

  return (
    <section style={{ marginTop: "2.5rem" }}>
      <h2>Registry items</h2>
      <div className="card" style={{ padding: "1.25rem", marginTop: "1rem" }}>
        <form onSubmit={addItem}>
          <div className="field">
            <label>Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label>Price in dollars</label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="Leave blank for a cash gift with no set goal"
            />
          </div>
          <div className="field">
            <label>Photo URL</label>
            <input
              type="url"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
            />
            {uploadsEnabled && (
              <div style={{ marginTop: "0.5rem" }}>
                <input
                  type="file"
                  accept="image/*"
                  disabled={uploading}
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) uploadFile(f, setPhotoUrl);
                  }}
                />
                {uploading && (
                  <span className="muted" style={{ fontSize: "0.8rem" }}>
                    {" "}
                    Uploading…
                  </span>
                )}
              </div>
            )}
          </div>
          <div className="field">
            <label>Category (optional)</label>
            <input
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              placeholder="e.g. Kitchen, Bedroom, Experiences"
            />
          </div>
          <div className="field">
            <label>Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="field">
            <label
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "0.5rem",
              }}
            >
              <input
                type="checkbox"
                style={{ width: "auto" }}
                checked={isCashGift}
                onChange={(e) => setIsCashGift(e.target.checked)}
              />
              This is a cash gift (guests give money directly — unrestricted)
            </label>
            <p
              className="muted"
              style={{ fontSize: "0.8rem", marginTop: "0.35rem" }}
            >
              No &ldquo;fund&rdquo; theme needed. Guests contribute any amount;
              use the price as an optional goal, or 0 for no goal.
            </p>
          </div>
          <div className="field">
            <label
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "0.5rem",
              }}
            >
              <input
                type="checkbox"
                style={{ width: "auto" }}
                checked={allowPartial}
                onChange={(e) => setAllowPartial(e.target.checked)}
              />
              Allow group gifting (guests contribute partial amounts)
            </label>
            <p
              className="muted"
              style={{ fontSize: "0.8rem", marginTop: "0.35rem" }}
            >
              Not sure? Leave both unticked for a normal gift one guest claims.
              Tick <em>cash gift</em> for a money gift, or <em>group gifting</em>{" "}
              to let several guests split the cost of one item.
            </p>
          </div>
          <button className="btn btn-primary" disabled={busy}>
            Add item
          </button>
        </form>
      </div>
      {error && <p style={{ color: "crimson" }}>{error}</p>}
      {items.length === 0 ? (
        <p className="muted" style={{ marginTop: "1.5rem" }}>
          No items yet. Add your first gift above.
        </p>
      ) : (
        <div className="stack" style={{ marginTop: "1.5rem" }}>
          {items.map((item) => (
            <div
              key={item.id}
              className="card"
              style={{
                padding: "1rem",
                display: "flex",
                gap: "1rem",
                alignItems: "flex-start",
                justifyContent: "space-between",
              }}
            >
              {editingId === item.id ? (
                <div className="stack" style={{ flex: 1 }}>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    required
                  />
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={editPrice}
                    onChange={(e) => setEditPrice(e.target.value)}
                    required
                  />
                  <input
                    type="url"
                    value={editPhotoUrl}
                    onChange={(e) => setEditPhotoUrl(e.target.value)}
                  />
                  {uploadsEnabled && (
                    <input
                      type="file"
                      accept="image/*"
                      disabled={uploading}
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) uploadFile(f, setEditPhotoUrl);
                      }}
                    />
                  )}
                  <input
                    type="text"
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                    placeholder="Category (optional)"
                  />
                  <textarea
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                  />
                  <label
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "0.5rem",
                    }}
                  >
                    <input
                      type="checkbox"
                      style={{ width: "auto" }}
                      checked={editIsCashGift}
                      onChange={(e) => setEditIsCashGift(e.target.checked)}
                    />
                    Cash gift (unrestricted)
                  </label>
                  <label
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "0.5rem",
                    }}
                  >
                    <input
                      type="checkbox"
                      style={{ width: "auto" }}
                      checked={editAllowPartial}
                      onChange={(e) => setEditAllowPartial(e.target.checked)}
                    />
                    Allow group gifting (guests contribute partial amounts)
                  </label>
                  <div style={{ display: "flex", gap: "0.5rem" }}>
                    <button
                      className="btn btn-primary"
                      onClick={() => saveEdit(item.id)}
                      disabled={busy}
                    >
                      Save
                    </button>
                    <button className="btn btn-secondary" onClick={cancelEdit}>
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div>
                    <strong>{item.name}</strong>
                    {item.isCashGift ? (
                      <span className="badge" style={{ marginLeft: "0.5rem" }}>
                        Cash gift
                      </span>
                    ) : (
                      item.allowPartial && (
                        <span
                          className="badge"
                          style={{ marginLeft: "0.5rem" }}
                        >
                          Group gift
                        </span>
                      )
                    )}
                    <div className="muted">{formatCents(item.priceCents)}</div>
                    {item.description && (
                      <div className="muted" style={{ fontSize: "0.85rem" }}>
                        {item.description}
                      </div>
                    )}
                  </div>
                  <div style={{ display: "flex", gap: "0.5rem" }}>
                    <button
                      className="btn btn-secondary"
                      onClick={() => startEdit(item)}
                    >
                      Edit
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => deleteItem(item.id)}
                    >
                      Delete
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
