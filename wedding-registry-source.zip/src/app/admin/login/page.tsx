import { redirect } from "next/navigation";
import { isSetupComplete } from "@/lib/config";
import { isAdminAuthenticated } from "@/lib/auth";
import LoginForm from "./LoginForm";

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  if (!(await isSetupComplete())) redirect("/setup");
  if (await isAdminAuthenticated()) redirect("/admin");

  return (
    <main className="container" style={{ maxWidth: "420px", padding: "4rem 0" }}>
      <div className="center stack" style={{ marginBottom: "1.5rem" }}>
        <h1>Couple login</h1>
        <p className="muted">Enter your admin password.</p>
      </div>
      <div className="card" style={{ padding: "1.75rem" }}>
        <LoginForm />
      </div>
    </main>
  );
}
