"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatCents } from "@/lib/format";

export interface ThankYouRow {
  id: string;
  guestName: string;
  itemName: string;
  amountCents: number;
  guestContact: string | null;
  message: string | null;
  thankYouSent: boolean;
  thankYouAtLabel: string | null;
  createdAtLabel: string;
}

export default function AdminThankYous({ rows }: { rows: ThankYouRow[] }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [showPendingOnly, setShowPendingOnly] = useState<boolean>(true);

  const pendingCount = rows.filter((r) => !r.thankYouSent).length;
  const visible = showPendingOnly ? rows.filter((r) => !r.thankYouSent) : rows;

  async function setThankYou(id: string, sent: boolean) {
    setBusyId(id);
    setError(null);

    try {
      const res = await fetch(`/api/admin/contributions/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ thankYouSent: sent }),
      });

      if (res.ok) {
        router.refresh();
      } else {
        setError((await res.json().catch(() => ({}))).error || "Update failed");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section style={{ marginTop: "2.5rem" }}>
      <h2>Thank-yous</h2>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: "1rem",
          flexWrap: "wrap",
          marginTop: "0.25rem",
        }}
      >
        <p className="muted" style={{ margin: 0 }}>
          {pendingCount} pending thank-you{pendingCount === 1 ? "" : "s"}.
        </p>
        <label
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "0.4rem",
          }}
        >
          <input
            type="checkbox"
            style={{ width: "auto" }}
            checked={showPendingOnly}
            onChange={(e) => setShowPendingOnly(e.target.checked)}
          />
          Show pending only
        </label>
      </div>
      {error && <p style={{ color: "crimson" }}>{error}</p>}
      {visible.length === 0 ? (
        <p className="muted" style={{ marginTop: "1rem" }}>
          {showPendingOnly
            ? "No pending thank-yous — you're all caught up!"
            : "No contributions yet."}
        </p>
      ) : (
        <div className="stack" style={{ marginTop: "1rem" }}>
          {visible.map((r) => (
            <div
              key={r.id}
              className="card"
              style={{
                padding: "1rem",
                display: "flex",
                justifyContent: "space-between",
                gap: "1rem",
                alignItems: "flex-start",
                flexWrap: "wrap",
              }}
            >
              <div>
                <div>
                  <strong>{r.guestName}</strong>{" "}
                  <span className="muted">
                    · {formatCents(r.amountCents)} toward {r.itemName}
                  </span>
                </div>
                {r.guestContact ? (
                  <div style={{ fontSize: "0.88rem", marginTop: "0.2rem" }}>
                    Contact: {r.guestContact}
                  </div>
                ) : (
                  <div
                    className="muted"
                    style={{ fontSize: "0.85rem", marginTop: "0.2rem" }}
                  >
                    No contact provided
                  </div>
                )}
                {r.message && (
                  <div
                    className="muted"
                    style={{
                      fontSize: "0.85rem",
                      fontStyle: "italic",
                      marginTop: "0.2rem",
                    }}
                  >
                    &ldquo;{r.message}&rdquo;
                  </div>
                )}
              </div>
              <div style={{ textAlign: "right" }}>
                {r.thankYouSent ? (
                  <>
                    <div>
                      <span className="badge">
                        Sent
                        {r.thankYouAtLabel ? " · " + r.thankYouAtLabel : ""}
                      </span>
                    </div>
                    <button
                      className="btn btn-secondary"
                      style={{ marginTop: "0.5rem" }}
                      disabled={busyId === r.id}
                      onClick={() => setThankYou(r.id, false)}
                    >
                      Mark not sent
                    </button>
                  </>
                ) : (
                  <button
                    className="btn btn-primary"
                    disabled={busyId === r.id}
                    onClick={() => setThankYou(r.id, true)}
                  >
                    Mark thank-you sent
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
