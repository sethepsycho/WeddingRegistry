import { redirect } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getCouple } from "@/lib/config";
import { isAdminAuthenticated } from "@/lib/auth";
import { formatCents } from "@/lib/format";
import { fundedCents, fundedPercent, isFullyFunded } from "@/lib/funding";
import { isUploadsEnabled } from "@/lib/storage";
import LogoutButton from "./LogoutButton";
import AdminItems, { AdminItem } from "./AdminItems";
import AdminFunding, { AdminFundingItem } from "./AdminFunding";
import AdminExternalLinks, { AdminLink } from "./AdminExternalLinks";
import AdminThankYous, { ThankYouRow } from "./AdminThankYous";
import AdminRsvps, { RsvpRow } from "./AdminRsvps";
import AdminInvites, { AdminInvite } from "./AdminInvites";
import CoupleSettings from "./CoupleSettings";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  if (!(await isAdminAuthenticated())) redirect("/admin/login");

  const couple = await getCouple();
  if (!couple) redirect("/setup");

  // Independent reads run in parallel.
  const [items, externalLinks, rsvps, invites] = await Promise.all([
    prisma.item.findMany({
      orderBy: { createdAt: "asc" },
      include: { contributions: true, payment: true },
    }),
    prisma.externalLink.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    }),
    prisma.rsvp.findMany({
      orderBy: { createdAt: "desc" },
      include: { invite: { select: { householdName: true } } },
    }),
    prisma.invite.findMany({ orderBy: { householdName: "asc" } }),
  ]);

  // Stats
  const claimedOrFunded = items.filter((i) =>
    i.allowPartial
      ? isFullyFunded(i) || i.closed
      : i.contributions.length > 0
  ).length;
  const inProgress = items.filter(
    (i) =>
      i.allowPartial &&
      i.contributions.length > 0 &&
      !isFullyFunded(i) &&
      !i.closed
  ).length;
  const totalCashPledgedCents = items
    .filter((i) => i.fulfillment === "cash" && i.payment)
    .reduce((sum, i) => sum + (i.payment?.amountCents ?? 0), 0);
  const giftsPending = items.filter(
    (i) => i.fulfillment === "gift" && !i.giftReceived
  ).length;

  // Item CRUD list
  const adminItems: AdminItem[] = items.map((i) => ({
    id: i.id,
    name: i.name,
    description: i.description,
    priceCents: i.priceCents,
    photoUrl: i.photoUrl,
    category: i.category,
    allowPartial: i.allowPartial,
    isCashGift: i.isCashGift,
  }));

  // Funding / claims list: only items that have activity.
  const dateFmt = new Intl.DateTimeFormat("en-US", { dateStyle: "medium" });
  const fundingItems: AdminFundingItem[] = items
    .filter((i) => i.contributions.length > 0 || i.closed)
    .map((i) => ({
      id: i.id,
      name: i.name,
      priceCents: i.priceCents,
      allowPartial: i.allowPartial,
      closed: i.closed,
      fulfillment: i.fulfillment as "undecided" | "gift" | "cash",
      giftReceived: i.giftReceived,
      fundedCents: fundedCents(i),
      percent: fundedPercent(i),
      fullyFunded: isFullyFunded(i),
      pledgeAmountCents: i.payment ? i.payment.amountCents : null,
      contributions: [...i.contributions]
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
        .map((c) => ({
          id: c.id,
          guestName: c.guestName,
          message: c.message,
          amountCents: c.amountCents,
          needsAddress: c.needsAddress,
          createdAtLabel: dateFmt.format(c.createdAt),
        })),
    }));

  // Thank-you tracking rows: every contribution, flattened, newest first.
  const thankYouRows: ThankYouRow[] = items
    .flatMap((i) =>
      i.contributions.map((c) => ({ contribution: c, itemName: i.name }))
    )
    .sort(
      (a, b) =>
        b.contribution.createdAt.getTime() - a.contribution.createdAt.getTime()
    )
    .map(({ contribution: c, itemName }) => ({
      id: c.id,
      guestName: c.guestName,
      itemName,
      amountCents: c.amountCents,
      guestContact: c.guestContact,
      message: c.message,
      thankYouSent: c.thankYouSent,
      thankYouAtLabel: c.thankYouAt ? dateFmt.format(c.thankYouAt) : null,
      createdAtLabel: dateFmt.format(c.createdAt),
    }));
  const thankYousPending = thankYouRows.filter((r) => !r.thankYouSent).length;

  const adminLinks: AdminLink[] = externalLinks.map((l) => ({
    id: l.id,
    label: l.label,
    url: l.url,
    storeName: l.storeName,
  }));

  const rsvpRows: RsvpRow[] = rsvps.map((r) => ({
    id: r.id,
    guestName: r.guestName,
    attending: r.attending,
    partySize: r.partySize,
    message: r.message,
    contact: r.contact,
    householdName: r.invite?.householdName ?? null,
    createdAtLabel: dateFmt.format(r.createdAt),
  }));

  const adminInvites: AdminInvite[] = invites.map((i) => ({
    id: i.id,
    householdName: i.householdName,
    maxPartySize: i.maxPartySize,
    code: i.code,
  }));

  const weddingDateInput = couple.weddingDate
    ? couple.weddingDate.toISOString().slice(0, 10)
    : "";

  return (
    <>
      <header className="site-header">
        <div className="container site-header-inner">
          <span className="brand">
            Admin · {couple.partner1} &amp; {couple.partner2}
          </span>
          <div style={{ display: "flex", gap: "0.5rem" }}>
            <Link href="/" className="btn btn-secondary">
              View site
            </Link>
            <LogoutButton />
          </div>
        </div>
      </header>
      <main className="container" style={{ padding: "2rem 0" }}>
        <div className="stat-grid">
          <div className="stat">
            <div className="stat-value">{claimedOrFunded}</div>
            <div className="stat-label">Claimed / funded</div>
          </div>
          <div className="stat">
            <div className="stat-value">{inProgress}</div>
            <div className="stat-label">Group gifts in progress</div>
          </div>
          <div className="stat">
            <div className="stat-value">
              {formatCents(totalCashPledgedCents)}
            </div>
            <div className="stat-label">Cash promised</div>
          </div>
          <div className="stat">
            <div className="stat-value">{giftsPending}</div>
            <div className="stat-label">Gifts pending</div>
          </div>
          <div className="stat">
            <div className="stat-value">{thankYousPending}</div>
            <div className="stat-label">Thank-yous pending</div>
          </div>
        </div>
        <p className="muted" style={{ marginTop: "1rem", fontSize: "0.9rem" }}>
          Tip: your registry starts with a few example gifts and RSVPs so you can
          see how it works — edit or delete them below, and set your own names,
          date, and theme in <strong>Couple &amp; event</strong> at the bottom.
        </p>
        <AdminItems items={adminItems} uploadsEnabled={isUploadsEnabled()} />
        <AdminFunding items={fundingItems} />
        <AdminThankYous rows={thankYouRows} />
        <AdminRsvps rsvps={rsvpRows} />
        <AdminInvites invites={adminInvites} />
        <AdminExternalLinks links={adminLinks} />
        <CoupleSettings
          partner1={couple.partner1}
          partner2={couple.partner2}
          weddingDate={weddingDateInput}
          theme={couple.theme}
          welcomeMessage={couple.welcomeMessage ?? ""}
          mailingAddress={couple.mailingAddress ?? ""}
          notifyEmail={couple.notifyEmail ?? ""}
          rsvpEnabled={couple.rsvpEnabled}
          rsvpDefaultMaxParty={couple.rsvpDefaultMaxParty}
        />
      </main>
    </>
  );
}
