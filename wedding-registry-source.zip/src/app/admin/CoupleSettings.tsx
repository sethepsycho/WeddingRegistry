"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { THEMES } from "@/lib/themes";

interface Props {
  partner1: string;
  partner2: string;
  weddingDate: string;
  theme: string;
  welcomeMessage: string;
  mailingAddress: string;
  notifyEmail: string;
  rsvpEnabled: boolean;
  rsvpDefaultMaxParty: number;
}

export default function CoupleSettings(props: Props) {
  const [partner1, setPartner1] = useState(props.partner1);
  const [partner2, setPartner2] = useState(props.partner2);
  const [weddingDate, setWeddingDate] = useState(props.weddingDate);
  const [theme, setTheme] = useState(props.theme);
  const [welcomeMessage, setWelcomeMessage] = useState(props.welcomeMessage);
  const [mailingAddress, setMailingAddress] = useState(props.mailingAddress);
  const [notifyEmail, setNotifyEmail] = useState(props.notifyEmail);
  const [rsvpEnabled, setRsvpEnabled] = useState(props.rsvpEnabled);
  const [rsvpDefaultMaxParty, setRsvpDefaultMaxParty] = useState(
    String(props.rsvpDefaultMaxParty)
  );
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSaved(false);

    try {
      const res = await fetch("/api/admin/couple", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          partner1,
          partner2,
          weddingDate,
          theme,
          welcomeMessage,
          mailingAddress,
          notifyEmail,
          rsvpEnabled,
          rsvpDefaultMaxParty: Number(rsvpDefaultMaxParty),
        }),
      });

      if (res.ok) {
        setSaved(true);
        router.refresh();
      } else {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        setError(data.error || "Failed to save");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section style={{ marginTop: "2.5rem" }}>
      <h2>Couple &amp; event</h2>
      <div className="card" style={{ padding: "1.25rem", marginTop: "1rem" }}>
        <form onSubmit={save}>
          <div className="field">
            <label htmlFor="partner1">Partner 1 name</label>
            <input
              type="text"
              id="partner1"
              value={partner1}
              onChange={(e) => {
                setPartner1(e.target.value);
                setSaved(false);
              }}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="partner2">Partner 2 name</label>
            <input
              type="text"
              id="partner2"
              value={partner2}
              onChange={(e) => {
                setPartner2(e.target.value);
                setSaved(false);
              }}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="weddingDate">Wedding date</label>
            <input
              type="date"
              id="weddingDate"
              value={weddingDate}
              onChange={(e) => {
                setWeddingDate(e.target.value);
                setSaved(false);
              }}
            />
          </div>
          <div className="field">
            <label htmlFor="theme">Theme</label>
            <select
              id="theme"
              value={theme}
              onChange={(e) => {
                setTheme(e.target.value);
                setSaved(false);
              }}
            >
              {THEMES.map((t) => (
                <option key={t.key} value={t.key}>
                  {t.label}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="welcomeMessage">Welcome message</label>
            <textarea
              id="welcomeMessage"
              value={welcomeMessage}
              onChange={(e) => {
                setWelcomeMessage(e.target.value);
                setSaved(false);
              }}
            />
          </div>
          <div className="field">
            <label htmlFor="mailingAddress">
              Mailing address (private)
            </label>
            <textarea
              id="mailingAddress"
              value={mailingAddress}
              onChange={(e) => {
                setMailingAddress(e.target.value);
                setSaved(false);
              }}
              placeholder="Only shown to guests who choose they need it to ship a gift."
            />
          </div>
          <div className="field">
            <label htmlFor="notifyEmail">Notification email (optional)</label>
            <input
              type="email"
              id="notifyEmail"
              value={notifyEmail}
              onChange={(e) => {
                setNotifyEmail(e.target.value);
                setSaved(false);
              }}
              placeholder="Where to send claim / RSVP notifications"
            />
          </div>
          <div className="field">
            <label
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "0.5rem",
              }}
            >
              <input
                type="checkbox"
                style={{ width: "auto" }}
                checked={rsvpEnabled}
                onChange={(e) => {
                  setRsvpEnabled(e.target.checked);
                  setSaved(false);
                }}
              />
              Enable the public RSVP page
            </label>
          </div>
          <div className="field">
            <label htmlFor="rsvpDefaultMaxParty">
              Default party-size limit
            </label>
            <input
              type="number"
              id="rsvpDefaultMaxParty"
              min="1"
              max="20"
              value={rsvpDefaultMaxParty}
              onChange={(e) => {
                setRsvpDefaultMaxParty(e.target.value);
                setSaved(false);
              }}
            />
            <p className="muted" style={{ fontSize: "0.8rem", marginTop: "0.3rem" }}>
              Used for guests who aren&apos;t on your guest list. Set per-invite
              limits in the Guest list section below.
            </p>
          </div>
          {error && <p style={{ color: "crimson" }}>{error}</p>}
          <div>
            <button type="submit" className="btn btn-primary" disabled={busy}>
              {busy ? "Saving…" : "Save changes"}
            </button>
            {saved && (
              <span className="muted" style={{ marginLeft: "0.75rem" }}>
                Saved ✓
              </span>
            )}
          </div>
        </form>
      </div>
    </section>
  );
}
