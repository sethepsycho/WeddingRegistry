"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export interface RsvpRow {
  id: string;
  guestName: string;
  attending: boolean;
  partySize: number;
  message: string | null;
  contact: string | null;
  householdName: string | null;
  createdAtLabel: string;
}

export default function AdminRsvps({ rsvps }: { rsvps: RsvpRow[] }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const attendingRows = rsvps.filter((r) => r.attending);
  const guestCount = attendingRows.reduce((s, r) => s + r.partySize, 0);
  const declined = rsvps.length - attendingRows.length;

  async function remove(id: string) {
    if (!confirm("Delete this RSVP?")) return;
    setBusyId(id);
    setError(null);

    try {
      const res = await fetch(`/api/admin/rsvps/${id}`, { method: "DELETE" });
      if (res.ok) {
        router.refresh();
      } else {
        setError((await res.json().catch(() => ({}))).error || "Delete failed");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section style={{ marginTop: "2.5rem" }}>
      <h2>RSVPs</h2>
      <div className="stat-grid" style={{ marginTop: "1rem" }}>
        <div className="stat">
          <div className="stat-value">{attendingRows.length}</div>
          <div className="stat-label">Parties attending</div>
        </div>
        <div className="stat">
          <div className="stat-value">{guestCount}</div>
          <div className="stat-label">Total guests</div>
        </div>
        <div className="stat">
          <div className="stat-value">{declined}</div>
          <div className="stat-label">Can&apos;t make it</div>
        </div>
      </div>
      {error && <p style={{ color: "crimson" }}>{error}</p>}
      {rsvps.length === 0 ? (
        <p className="muted" style={{ marginTop: "1rem" }}>
          No RSVPs yet.
        </p>
      ) : (
        <div className="stack" style={{ marginTop: "1.5rem" }}>
          {rsvps.map((r) => (
            <div
              key={r.id}
              className="card"
              style={{
                padding: "1rem",
                display: "flex",
                justifyContent: "space-between",
                gap: "1rem",
                alignItems: "flex-start",
                flexWrap: "wrap",
              }}
            >
              <div>
                <div>
                  <strong>{r.guestName}</strong>{" "}
                  <span className="badge" style={{ marginLeft: "0.5rem" }}>
                    {r.attending
                      ? `Attending · party of ${r.partySize}`
                      : "Declined"}
                  </span>
                </div>
                <div
                  className="muted"
                  style={{ fontSize: "0.85rem", marginTop: "0.2rem" }}
                >
                  {r.createdAtLabel}
                  {r.householdName ? ` · ${r.householdName}` : ""}
                  {r.contact ? ` · ${r.contact}` : ""}
                </div>
                {r.message && (
                  <div
                    className="muted"
                    style={{
                      fontSize: "0.85rem",
                      fontStyle: "italic",
                      marginTop: "0.2rem",
                    }}
                  >
                    &ldquo;{r.message}&rdquo;
                  </div>
                )}
              </div>
              <button
                className="btn btn-secondary"
                disabled={busyId === r.id}
                onClick={() => remove(r.id)}
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
