"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export interface AdminLink {
  id: string;
  label: string;
  url: string;
  storeName: string | null;
}

export default function AdminExternalLinks({ links }: { links: AdminLink[] }) {
  const router = useRouter();
  const [label, setLabel] = useState("");
  const [url, setUrl] = useState("");
  const [storeName, setStoreName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editLabel, setEditLabel] = useState("");
  const [editUrl, setEditUrl] = useState("");
  const [editStoreName, setEditStoreName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function addLink(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);

    try {
      const res = await fetch("/api/external-links", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ label, url, storeName }),
      });
      if (res.ok) {
        setLabel("");
        setUrl("");
        setStoreName("");
        router.refresh();
      } else {
        setError((await res.json().catch(() => ({}))).error || "Failed to add link");
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  function startEdit(link: AdminLink) {
    setEditingId(link.id);
    setEditLabel(link.label);
    setEditUrl(link.url);
    setEditStoreName(link.storeName || "");
  }

  const cancelEdit = () => setEditingId(null);

  async function saveEdit(id: string) {
    if (busy) return;
    setBusy(true);
    setError(null);

    try {
      const res = await fetch(`/api/external-links/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          label: editLabel,
          url: editUrl,
          storeName: editStoreName,
        }),
      });
      if (res.ok) {
        setEditingId(null);
        router.refresh();
      } else {
        setError(
          (await res.json().catch(() => ({}))).error || "Failed to update link"
        );
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  async function deleteLink(id: string) {
    if (!confirm("Delete this external registry link?")) return;
    if (busy) return;
    setBusy(true);
    setError(null);

    try {
      const res = await fetch(`/api/external-links/${id}`, { method: "DELETE" });
      if (res.ok) {
        router.refresh();
      } else {
        setError(
          (await res.json().catch(() => ({}))).error || "Failed to delete link"
        );
      }
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section style={{ marginTop: "2.5rem" }}>
      <h2>External registries</h2>
      <p className="muted" style={{ marginTop: "0.25rem" }}>
        Links to registries hosted elsewhere. These appear on your registry
        page, separate from your own items.
      </p>

      <div className="card" style={{ padding: "1.25rem", marginTop: "1rem" }}>
        <form onSubmit={addLink}>
          <div className="field">
            <label htmlFor="link-label">Label</label>
            <input
              type="text"
              id="link-label"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="Amazon Registry"
              required
            />
          </div>
          <div className="field">
            <label htmlFor="link-url">URL</label>
            <input
              type="url"
              id="link-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://…"
              required
            />
          </div>
          <div className="field">
            <label htmlFor="link-store">Store name (optional)</label>
            <input
              type="text"
              id="link-store"
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              placeholder="Amazon"
            />
          </div>
          <button className="btn btn-primary" disabled={busy}>
            Add link
          </button>
        </form>
      </div>

      {error && <p style={{ color: "crimson" }}>{error}</p>}

      {links.length === 0 ? (
        <p className="muted" style={{ marginTop: "1.5rem" }}>
          No external links yet.
        </p>
      ) : (
        <div className="stack" style={{ marginTop: "1.5rem" }}>
          {links.map((link) => (
            <div
              key={link.id}
              className="card"
              style={{
                padding: "1rem",
                display: "flex",
                gap: "1rem",
                justifyContent: "space-between",
                alignItems: "flex-start",
              }}
            >
              {editingId === link.id ? (
                <div className="stack" style={{ flex: 1 }}>
                  <input
                    type="text"
                    value={editLabel}
                    onChange={(e) => setEditLabel(e.target.value)}
                    placeholder="Label"
                    required
                  />
                  <input
                    type="url"
                    value={editUrl}
                    onChange={(e) => setEditUrl(e.target.value)}
                    placeholder="URL"
                    required
                  />
                  <input
                    type="text"
                    value={editStoreName}
                    onChange={(e) => setEditStoreName(e.target.value)}
                    placeholder="Store name"
                  />
                  <div style={{ display: "flex", gap: "0.5rem" }}>
                    <button
                      className="btn btn-primary"
                      onClick={() => saveEdit(link.id)}
                      disabled={busy}
                    >
                      Save
                    </button>
                    <button className="btn btn-secondary" onClick={cancelEdit}>
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div>
                    <strong>{link.label}</strong>
                    {link.storeName && (
                      <span className="muted"> · {link.storeName}</span>
                    )}
                    <div
                      className="muted"
                      style={{ fontSize: "0.85rem", wordBreak: "break-all" }}
                    >
                      {link.url}
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: "0.5rem" }}>
                    <button
                      className="btn btn-secondary"
                      onClick={() => startEdit(link)}
                    >
                      Edit
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => deleteLink(link.id)}
                    >
                      Delete
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
