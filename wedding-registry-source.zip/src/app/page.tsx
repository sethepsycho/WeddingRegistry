import { redirect } from "next/navigation";
import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import { getPublicCouple } from "@/lib/config";
import { formatWeddingDate } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const couple = await getPublicCouple();

  if (!couple || !couple.setupComplete) {
    redirect("/setup");
  }

  const coupleName = `${couple.partner1} & ${couple.partner2}`;
  const dateLabel = formatWeddingDate(couple.weddingDate);

  return (
    <>
      <SiteHeader coupleName={coupleName} showRsvpLink={couple.rsvpEnabled} />
      <main className="container" style={{ padding: "4rem 0" }}>
        <div className="center stack">
          <p className="muted">We&apos;re getting married</p>
          <h1 style={{ fontSize: "3rem" }}>{coupleName}</h1>
          {dateLabel && <p className="muted">{dateLabel}</p>}
          {couple.welcomeMessage && (
            <p style={{ maxWidth: "560px", margin: "0 auto" }}>
              {couple.welcomeMessage}
            </p>
          )}
          <div style={{ display: "flex", gap: "0.75rem", justifyContent: "center" }}>
            <Link href="/registry" className="btn btn-primary">
              View Our Registry
            </Link>
            {couple.rsvpEnabled && (
              <Link href="/rsvp" className="btn btn-secondary">
                RSVP
              </Link>
            )}
          </div>
        </div>
      </main>
      <footer className="container center muted" style={{ padding: "2rem 0" }}>
        <Link href="/admin">Couple login</Link>
      </footer>
    </>
  );
}
